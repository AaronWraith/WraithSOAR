import Link from "next/link"
import { GhostIcon } from "@/components/icons/ghost-icon"
import { ClassificationBanner } from "@/components/classification-banner"
import { BookOpen, Code, FileText, Lightbulb, Search, Shield, Workflow, Server, Settings, Users } from "lucide-react"

export default function DocsPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <ClassificationBanner classification="unclassified" />

      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <Link href="/" className="flex items-center gap-2">
              <GhostIcon size={20} />
              <span className="text-xl font-bold">WRAITH</span>
            </Link>
          </div>

          <nav className="hidden md:flex items-center gap-6">
            <Link href="/features" className="text-sm font-medium text-muted-foreground hover:text-foreground">
              Features
            </Link>
            <Link href="/solutions" className="text-sm font-medium text-muted-foreground hover:text-foreground">
              Solutions
            </Link>
            <Link href="/pricing" className="text-sm font-medium text-muted-foreground hover:text-foreground">
              Pricing
            </Link>
            <Link href="/docs" className="text-sm font-medium text-foreground">
              Documentation
            </Link>
          </nav>

          <div className="flex items-center gap-4">
            <Link
              href="/platform"
              className="px-4 py-2 rounded-md bg-primary text-primary-foreground font-medium text-sm"
            >
              Launch Platform
            </Link>
          </div>
        </div>
      </header>

      <div className="flex-1 flex">
        {/* Sidebar */}
        <div className="w-64 border-r bg-muted/10 hidden md:block">
          <div className="p-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <input
                type="text"
                placeholder="Search documentation..."
                className="pl-10 pr-4 py-2 w-full border rounded-md bg-background text-sm"
              />
            </div>
          </div>
          <nav className="p-4">
            <div className="mb-4">
              <h4 className="text-sm font-medium text-muted-foreground mb-2">Getting Started</h4>
              <ul className="space-y-1">
                <li>
                  <Link href="/docs/introduction" className="text-sm hover:text-primary block py-1">
                    Introduction
                  </Link>
                </li>
                <li>
                  <Link href="/docs/quickstart" className="text-sm hover:text-primary block py-1">
                    Quick Start Guide
                  </Link>
                </li>
                <li>
                  <Link href="/docs/installation" className="text-sm hover:text-primary block py-1">
                    Installation
                  </Link>
                </li>
                <li>
                  <Link href="/docs/deployment" className="text-sm hover:text-primary block py-1">
                    Deployment Options
                  </Link>
                </li>
              </ul>
            </div>
            <div className="mb-4">
              <h4 className="text-sm font-medium text-muted-foreground mb-2">Core Concepts</h4>
              <ul className="space-y-1">
                <li>
                  <Link href="/docs/workflows" className="text-sm hover:text-primary block py-1">
                    Workflows
                  </Link>
                </li>
                <li>
                  <Link href="/docs/playbooks" className="text-sm hover:text-primary block py-1">
                    Playbooks
                  </Link>
                </li>
                <li>
                  <Link href="/docs/integrations" className="text-sm hover:text-primary block py-1">
                    Integrations
                  </Link>
                </li>
                <li>
                  <Link href="/docs/alerts" className="text-sm hover:text-primary block py-1">
                    Alerts
                  </Link>
                </li>
              </ul>
            </div>
            <div className="mb-4">
              <h4 className="text-sm font-medium text-muted-foreground mb-2">Advanced Features</h4>
              <ul className="space-y-1">
                <li>
                  <Link href="/docs/classification" className="text-sm hover:text-primary block py-1">
                    Classification Controls
                  </Link>
                </li>
                <li>
                  <Link href="/docs/cross-domain" className="text-sm hover:text-primary block py-1">
                    Cross-Domain Solutions
                  </Link>
                </li>
                <li>
                  <Link href="/docs/ai" className="text-sm hover:text-primary block py-1">
                    AI Integration
                  </Link>
                </li>
                <li>
                  <Link href="/docs/api" className="text-sm hover:text-primary block py-1">
                    API Reference
                  </Link>
                </li>
              </ul>
            </div>
          </nav>
        </div>

        {/* Main Content */}
        <main className="flex-1 p-8">
          <div className="max-w-3xl mx-auto">
            <h1 className="text-4xl font-bold mb-6">WRAITH SOAR Documentation</h1>
            <p className="text-xl text-muted-foreground mb-8">
              Welcome to the WRAITH SOAR documentation. Here you'll find comprehensive guides and documentation to help
              you start working with WRAITH SOAR as quickly as possible.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
              <Link
                href="/docs/quickstart"
                className="rounded-lg border bg-card p-6 hover:border-primary transition-colors"
              >
                <div className="flex items-start gap-4">
                  <div className="bg-primary/10 p-2 rounded-md">
                    <Lightbulb className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h2 className="text-xl font-semibold mb-2">Quick Start Guide</h2>
                    <p className="text-muted-foreground">
                      Get up and running with WRAITH SOAR in minutes with our quick start guide.
                    </p>
                  </div>
                </div>
              </Link>

              <Link
                href="/docs/workflows"
                className="rounded-lg border bg-card p-6 hover:border-primary transition-colors"
              >
                <div className="flex items-start gap-4">
                  <div className="bg-primary/10 p-2 rounded-md">
                    <Workflow className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h2 className="text-xl font-semibold mb-2">Workflow Builder</h2>
                    <p className="text-muted-foreground">
                      Learn how to create and customize security workflows with our visual builder.
                    </p>
                  </div>
                </div>
              </Link>
            </div>

            <h2 className="text-2xl font-bold mb-4">Documentation Categories</h2>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
              <div className="rounded-lg border bg-card p-6">
                <div className="mb-4 text-primary">
                  <BookOpen size={24} />
                </div>
                <h3 className="text-lg font-semibold mb-2">User Guides</h3>
                <p className="text-muted-foreground mb-4">
                  Comprehensive guides for using all features of the WRAITH SOAR platform
                </p>
                <Link href="/docs/guides" className="text-primary hover:underline text-sm">
                  Browse User Guides →
                </Link>
              </div>

              <div className="rounded-lg border bg-card p-6">
                <div className="mb-4 text-primary">
                  <Server size={24} />
                </div>
                <h3 className="text-lg font-semibold mb-2">Deployment</h3>
                <p className="text-muted-foreground mb-4">
                  Learn how to deploy WRAITH SOAR in various environments, including air-gapped networks
                </p>
                <Link href="/docs/deployment" className="text-primary hover:underline text-sm">
                  View Deployment Guides →
                </Link>
              </div>

              <div className="rounded-lg border bg-card p-6">
                <div className="mb-4 text-primary">
                  <Code size={24} />
                </div>
                <h3 className="text-lg font-semibold mb-2">API Reference</h3>
                <p className="text-muted-foreground mb-4">
                  Complete API documentation for integrating with WRAITH SOAR programmatically
                </p>
                <Link href="/docs/api" className="text-primary hover:underline text-sm">
                  Explore API Docs →
                </Link>
              </div>

              <div className="rounded-lg border bg-card p-6">
                <div className="mb-4 text-primary">
                  <Shield size={24} />
                </div>
                <h3 className="text-lg font-semibold mb-2">Security Features</h3>
                <p className="text-muted-foreground mb-4">
                  Detailed documentation on military-grade security features and compliance
                </p>
                <Link href="/docs/security" className="text-primary hover:underline text-sm">
                  Read Security Docs →
                </Link>
              </div>

              <div className="rounded-lg border bg-card p-6">
                <div className="mb-4 text-primary">
                  <Settings size={24} />
                </div>
                <h3 className="text-lg font-semibold mb-2">Administration</h3>
                <p className="text-muted-foreground mb-4">
                  Guides for platform administrators on user management, configuration, and maintenance
                </p>
                <Link href="/docs/admin" className="text-primary hover:underline text-sm">
                  View Admin Guides →
                </Link>
              </div>

              <div className="rounded-lg border bg-card p-6">
                <div className="mb-4 text-primary">
                  <FileText size={24} />
                </div>
                <h3 className="text-lg font-semibold mb-2">Tutorials</h3>
                <p className="text-muted-foreground mb-4">Step-by-step tutorials for common tasks and use cases</p>
                <Link href="/docs/tutorials" className="text-primary hover:underline text-sm">
                  Browse Tutorials →
                </Link>
              </div>
            </div>

            <div className="bg-muted/20 rounded-lg p-6 border">
              <div className="flex items-start gap-4">
                <div className="bg-blue-500/10 p-2 rounded-md">
                  <Users className="h-6 w-6 text-blue-500" />
                </div>
                <div>
                  <h2 className="text-xl font-semibold mb-2">Need Help?</h2>
                  <p className="text-muted-foreground mb-4">
                    Our support team is available to help you with any questions or issues you may have.
                  </p>
                  <div className="flex flex-col sm:flex-row gap-3">
                    <Link
                      href="/contact"
                      className="px-4 py-2 rounded-md bg-primary text-primary-foreground font-medium text-sm"
                    >
                      Contact Support
                    </Link>
                    <Link href="/docs/faq" className="px-4 py-2 rounded-md border bg-background font-medium text-sm">
                      View FAQs
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>

      <footer className="bg-background border-t py-12">
        <div className="container">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center gap-2 mb-4 md:mb-0">
              <GhostIcon className="text-[#39FF14]" size={20} />
              <span className="text-xl font-bold">WRAITH</span>
            </div>
            <div className="flex gap-8">
              <Link href="/about" className="text-sm text-muted-foreground hover:text-foreground">
                About
              </Link>
              <Link href="/contact" className="text-sm text-muted-foreground hover:text-foreground">
                Contact
              </Link>
              <Link href="/privacy" className="text-sm text-muted-foreground hover:text-foreground">
                Privacy
              </Link>
              <Link href="/terms" className="text-sm text-muted-foreground hover:text-foreground">
                Terms
              </Link>
            </div>
          </div>
          <div className="mt-8 text-center text-sm text-muted-foreground">
            © 2023 WRAITH Security. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  )
}
