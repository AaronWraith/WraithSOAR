import Link from "next/link"
import { Check, Shield, Zap, Lock } from "lucide-react"
import { GhostIcon } from "@/components/icons/ghost-icon"
import { ClassificationBanner } from "@/components/classification-banner"

export default function PricingPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <ClassificationBanner classification="unclassified" />

      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <Link href="/" className="flex items-center gap-2">
              <GhostIcon size={20} />
              <span className="text-xl font-bold">WRAITH</span>
            </Link>
          </div>

          <nav className="hidden md:flex items-center gap-6">
            <Link href="/features" className="text-sm font-medium text-muted-foreground hover:text-foreground">
              Features
            </Link>
            <Link href="/solutions" className="text-sm font-medium text-muted-foreground hover:text-foreground">
              Solutions
            </Link>
            <Link href="/pricing" className="text-sm font-medium text-foreground">
              Pricing
            </Link>
            <Link href="/docs" className="text-sm font-medium text-muted-foreground hover:text-foreground">
              Documentation
            </Link>
          </nav>

          <div className="flex items-center gap-4">
            <Link
              href="/platform"
              className="px-4 py-2 rounded-md bg-primary text-primary-foreground font-medium text-sm"
            >
              Launch Platform
            </Link>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="py-20 bg-gradient-to-b from-background to-muted/20">
          <div className="container">
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-6">Flexible Pricing for Every Security Need</h1>
              <p className="text-xl text-muted-foreground mb-8">
                Our hybrid pricing model combines predictable licensing with usage-based components to provide maximum
                flexibility and value
              </p>
            </div>
          </div>
        </section>

        {/* Pricing Tiers Section */}
        <section className="py-20">
          <div className="container">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {/* Standard Tier */}
              <div className="rounded-lg border bg-card overflow-hidden">
                <div className="p-6 border-b">
                  <h3 className="text-2xl font-bold mb-2">Standard</h3>
                  <p className="text-muted-foreground mb-4">For small security teams and organizations</p>
                  <div className="flex items-baseline">
                    <span className="text-3xl font-bold">$2,500</span>
                    <span className="text-muted-foreground ml-1">/month</span>
                  </div>
                  <p className="text-sm text-muted-foreground mt-2">Base license + usage</p>
                </div>
                <div className="p-6">
                  <h4 className="font-medium mb-4">Includes:</h4>
                  <ul className="space-y-3">
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-green-500 shrink-0 mt-0.5" />
                      <span>Up to 5 users</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-green-500 shrink-0 mt-0.5" />
                      <span>100 playbook executions/day</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-green-500 shrink-0 mt-0.5" />
                      <span>500 alerts/day</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-green-500 shrink-0 mt-0.5" />
                      <span>10 custom playbooks</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-green-500 shrink-0 mt-0.5" />
                      <span>Standard integrations</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-green-500 shrink-0 mt-0.5" />
                      <span>Email support</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-green-500 shrink-0 mt-0.5" />
                      <span>30-day data retention</span>
                    </li>
                  </ul>
                  <div className="mt-6">
                    <Link
                      href="/contact"
                      className="block w-full py-2 px-3 text-center rounded-md bg-primary text-primary-foreground font-medium"
                    >
                      Contact Sales
                    </Link>
                  </div>
                </div>
              </div>

              {/* Professional Tier */}
              <div className="rounded-lg border bg-card overflow-hidden relative">
                <div className="absolute top-0 right-0 bg-primary text-primary-foreground px-3 py-1 text-xs font-medium rounded-bl-lg">
                  Most Popular
                </div>
                <div className="p-6 border-b">
                  <h3 className="text-2xl font-bold mb-2">Professional</h3>
                  <p className="text-muted-foreground mb-4">For mid-sized security operations</p>
                  <div className="flex items-baseline">
                    <span className="text-3xl font-bold">$6,000</span>
                    <span className="text-muted-foreground ml-1">/month</span>
                  </div>
                  <p className="text-sm text-muted-foreground mt-2">Base license + usage</p>
                </div>
                <div className="p-6">
                  <h4 className="font-medium mb-4">Includes:</h4>
                  <ul className="space-y-3">
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-green-500 shrink-0 mt-0.5" />
                      <span>Up to 15 users</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-green-500 shrink-0 mt-0.5" />
                      <span>500 playbook executions/day</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-green-500 shrink-0 mt-0.5" />
                      <span>2,500 alerts/day</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-green-500 shrink-0 mt-0.5" />
                      <span>Unlimited custom playbooks</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-green-500 shrink-0 mt-0.5" />
                      <span>Advanced integrations</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-green-500 shrink-0 mt-0.5" />
                      <span>Priority support with 8-hour SLA</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-green-500 shrink-0 mt-0.5" />
                      <span>90-day data retention</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-green-500 shrink-0 mt-0.5" />
                      <span>Advanced reporting</span>
                    </li>
                  </ul>
                  <div className="mt-6">
                    <Link
                      href="/contact"
                      className="block w-full py-2 px-3 text-center rounded-md bg-primary text-primary-foreground font-medium"
                    >
                      Contact Sales
                    </Link>
                  </div>
                </div>
              </div>

              {/* Enterprise Tier */}
              <div className="rounded-lg border bg-card overflow-hidden">
                <div className="p-6 border-b">
                  <h3 className="text-2xl font-bold mb-2">Enterprise</h3>
                  <p className="text-muted-foreground mb-4">For large organizations and defense agencies</p>
                  <div className="flex items-baseline">
                    <span className="text-3xl font-bold">Custom</span>
                  </div>
                  <p className="text-sm text-muted-foreground mt-2">Tailored licensing model</p>
                </div>
                <div className="p-6">
                  <h4 className="font-medium mb-4">Includes:</h4>
                  <ul className="space-y-3">
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-green-500 shrink-0 mt-0.5" />
                      <span>Unlimited users</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-green-500 shrink-0 mt-0.5" />
                      <span>Unlimited playbook executions</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-green-500 shrink-0 mt-0.5" />
                      <span>Unlimited alerts</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-green-500 shrink-0 mt-0.5" />
                      <span>Custom integrations</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-green-500 shrink-0 mt-0.5" />
                      <span>24/7 dedicated support with 4-hour SLA</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-green-500 shrink-0 mt-0.5" />
                      <span>Customizable data retention</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-green-500 shrink-0 mt-0.5" />
                      <span>Air-gapped deployment options</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-green-500 shrink-0 mt-0.5" />
                      <span>Classification controls</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-5 w-5 text-green-500 shrink-0 mt-0.5" />
                      <span>Cross-domain solutions</span>
                    </li>
                  </ul>
                  <div className="mt-6">
                    <Link
                      href="/contact"
                      className="block w-full py-2 px-3 text-center rounded-md bg-primary text-primary-foreground font-medium"
                    >
                      Contact Sales
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Usage-Based Components Section */}
        <section className="py-20 bg-muted/20">
          <div className="container">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold mb-4">Usage-Based Components</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Pay only for what you use beyond your base license
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              <div className="rounded-lg border bg-card p-6 shadow-sm">
                <h3 className="text-xl font-semibold mb-4">Playbook Executions</h3>
                <p className="text-muted-foreground mb-4">
                  Additional playbook executions beyond your plan's daily limit
                </p>
                <div className="text-2xl font-bold mb-2">$0.05</div>
                <p className="text-sm text-muted-foreground">per execution</p>
              </div>

              <div className="rounded-lg border bg-card p-6 shadow-sm">
                <h3 className="text-xl font-semibold mb-4">Alert Processing</h3>
                <p className="text-muted-foreground mb-4">Additional alerts processed beyond your plan's daily limit</p>
                <div className="text-2xl font-bold mb-2">$0.02</div>
                <p className="text-sm text-muted-foreground">per alert</p>
              </div>

              <div className="rounded-lg border bg-card p-6 shadow-sm">
                <h3 className="text-xl font-semibold mb-4">Data Storage</h3>
                <p className="text-muted-foreground mb-4">
                  Additional data storage beyond your plan's retention period
                </p>
                <div className="text-2xl font-bold mb-2">$0.10</div>
                <p className="text-sm text-muted-foreground">per GB/month</p>
              </div>

              <div className="rounded-lg border bg-card p-6 shadow-sm">
                <h3 className="text-xl font-semibold mb-4">API Calls</h3>
                <p className="text-muted-foreground mb-4">External API calls made by your playbooks and integrations</p>
                <div className="text-2xl font-bold mb-2">$0.001</div>
                <p className="text-sm text-muted-foreground">per API call</p>
              </div>
            </div>
          </div>
        </section>

        {/* Add-Ons Section */}
        <section className="py-20">
          <div className="container">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold mb-4">Optional Add-Ons</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Enhance your WRAITH SOAR platform with additional capabilities
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="rounded-lg border bg-card p-6 shadow-sm">
                <div className="mb-4 text-primary">
                  <Shield size={32} />
                </div>
                <h3 className="text-xl font-semibold mb-2">Advanced Threat Intelligence</h3>
                <p className="text-muted-foreground mb-4">
                  Premium threat intelligence feeds and advanced correlation capabilities
                </p>
                <div className="text-xl font-bold mb-2">$1,500/month</div>
              </div>

              <div className="rounded-lg border bg-card p-6 shadow-sm">
                <div className="mb-4 text-primary">
                  <Zap size={32} />
                </div>
                <h3 className="text-xl font-semibold mb-2">AI Automation</h3>
                <p className="text-muted-foreground mb-4">
                  AI-powered automation for alert triage, threat hunting, and incident response
                </p>
                <div className="text-xl font-bold mb-2">$2,000/month</div>
              </div>

              <div className="rounded-lg border bg-card p-6 shadow-sm">
                <div className="mb-4 text-primary">
                  <Lock size={32} />
                </div>
                <h3 className="text-xl font-semibold mb-2">Cross-Domain Solution</h3>
                <p className="text-muted-foreground mb-4">
                  Secure data transfer between different security domains and classification levels
                </p>
                <div className="text-xl font-bold mb-2">$3,500/month</div>
              </div>
            </div>
          </div>
        </section>

        {/* Comparison Section */}
        <section className="py-20 bg-muted/20">
          <div className="container">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold mb-4">How We Compare</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                See how WRAITH SOAR compares to other leading SOAR platforms
              </p>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full border-collapse">
                <thead>
                  <tr className="border-b">
                    <th className="text-left p-4">Feature</th>
                    <th className="text-center p-4">WRAITH SOAR</th>
                    <th className="text-center p-4">Splunk Phantom</th>
                    <th className="text-center p-4">Palo Alto Cortex XSOAR</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b">
                    <td className="p-4">Base Price</td>
                    <td className="text-center p-4">$2,500/month</td>
                    <td className="text-center p-4">$3,800/month</td>
                    <td className="text-center p-4">$4,200/month</td>
                  </tr>
                  <tr className="border-b">
                    <td className="p-4">Pricing Model</td>
                    <td className="text-center p-4">Hybrid (License + Usage)</td>
                    <td className="text-center p-4">Event-based + Annual License</td>
                    <td className="text-center p-4">User-based + Playbook Execution</td>
                  </tr>
                  <tr className="border-b">
                    <td className="p-4">Air-Gapped Deployment</td>
                    <td className="text-center p-4 text-green-500">✓</td>
                    <td className="text-center p-4 text-green-500">✓</td>
                    <td className="text-center p-4 text-green-500">✓</td>
                  </tr>
                  <tr className="border-b">
                    <td className="p-4">Classification Controls</td>
                    <td className="text-center p-4 text-green-500">✓</td>
                    <td className="text-center p-4 text-red-500">Limited</td>
                    <td className="text-center p-4 text-red-500">Limited</td>
                  </tr>
                  <tr className="border-b">
                    <td className="p-4">Custom Playbooks</td>
                    <td className="text-center p-4">Unlimited</td>
                    <td className="text-center p-4">Unlimited</td>
                    <td className="text-center p-4">Unlimited</td>
                  </tr>
                  <tr className="border-b">
                    <td className="p-4">Integrations</td>
                    <td className="text-center p-4">300+</td>
                    <td className="text-center p-4">350+</td>
                    <td className="text-center p-4">450+</td>
                  </tr>
                  <tr className="border-b">
                    <td className="p-4">AI Capabilities</td>
                    <td className="text-center p-4 text-green-500">✓</td>
                    <td className="text-center p-4 text-green-500">✓</td>
                    <td className="text-center p-4 text-green-500">✓</td>
                  </tr>
                  <tr className="border-b">
                    <td className="p-4">Visual Workflow Builder</td>
                    <td className="text-center p-4 text-green-500">Advanced</td>
                    <td className="text-center p-4 text-green-500">Basic</td>
                    <td className="text-center p-4 text-green-500">Advanced</td>
                  </tr>
                  <tr className="border-b">
                    <td className="p-4">Cross-Domain Solutions</td>
                    <td className="text-center p-4 text-green-500">✓</td>
                    <td className="text-center p-4 text-red-500">✗</td>
                    <td className="text-center p-4 text-red-500">✗</td>
                  </tr>
                  <tr className="border-b">
                    <td className="p-4">Deployment Options</td>
                    <td className="text-center p-4">On-Prem, Private Cloud, Hybrid</td>
                    <td className="text-center p-4">On-Prem, Cloud</td>
                    <td className="text-center p-4">On-Prem, Cloud, SaaS</td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div className="mt-8 text-sm text-muted-foreground text-center">
              <p>
                * Pricing and features based on publicly available information as of 2023. Contact vendors for current
                pricing.
              </p>
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="py-20">
          <div className="container">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold mb-4">Frequently Asked Questions</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Find answers to common questions about our pricing and licensing
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
              <div>
                <h3 className="text-xl font-semibold mb-3">How does the hybrid pricing model work?</h3>
                <p className="text-muted-foreground">
                  Our hybrid model includes a base license fee that covers a set number of users, playbook executions,
                  and alerts. Beyond these limits, you pay only for what you use with our usage-based components.
                </p>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-3">Can I upgrade my plan at any time?</h3>
                <p className="text-muted-foreground">
                  Yes, you can upgrade your plan at any time. The new pricing will be prorated for the remainder of your
                  billing cycle.
                </p>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-3">Do you offer discounts for annual commitments?</h3>
                <p className="text-muted-foreground">
                  Yes, we offer a 15% discount for annual commitments on all plans. Contact our sales team for details.
                </p>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-3">What happens if I exceed my usage limits?</h3>
                <p className="text-muted-foreground">
                  You'll automatically be billed for the additional usage at the rates listed in the Usage-Based
                  Components section. We'll never throttle or limit your platform's functionality.
                </p>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-3">Do you offer a free trial?</h3>
                <p className="text-muted-foreground">
                  Yes, we offer a 30-day free trial of our Professional plan. Contact our sales team to get started.
                </p>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-3">What payment methods do you accept?</h3>
                <p className="text-muted-foreground">
                  We accept credit cards, ACH transfers, and purchase orders for Enterprise customers.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-gradient-to-br from-black to-zinc-900">
          <div className="container">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-white">Ready to Get Started with WRAITH SOAR?</h2>
              <p className="text-xl text-gray-300 mb-8">
                Contact our sales team to discuss your specific requirements and find the right plan for your
                organization
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link
                  href="/contact"
                  className="px-8 py-3 rounded-md bg-[#39FF14] text-black font-medium hover:bg-[#39FF14]/90"
                >
                  Contact Sales
                </Link>
                <Link
                  href="/platform"
                  className="px-8 py-3 rounded-md border border-white/20 text-white hover:bg-white/10 font-medium"
                >
                  Try Demo
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-background border-t py-12">
        <div className="container">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center gap-2 mb-4 md:mb-0">
              <GhostIcon className="text-[#39FF14]" size={20} />
              <span className="text-xl font-bold">WRAITH</span>
            </div>
            <div className="flex gap-8">
              <Link href="/about" className="text-sm text-muted-foreground hover:text-foreground">
                About
              </Link>
              <Link href="/contact" className="text-sm text-muted-foreground hover:text-foreground">
                Contact
              </Link>
              <Link href="/privacy" className="text-sm text-muted-foreground hover:text-foreground">
                Privacy
              </Link>
              <Link href="/terms" className="text-sm text-muted-foreground hover:text-foreground">
                Terms
              </Link>
            </div>
          </div>
          <div className="mt-8 text-center text-sm text-muted-foreground">
            © 2023 WRAITH Security. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  )
}
