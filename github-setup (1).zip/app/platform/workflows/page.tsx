"use client"

import { useState, useEffect } from "react"
import { ClassificationBanner } from "@/components/classification-banner"
import { GhostIcon } from "@/components/icons/ghost-icon"
import { useWorkflowStore } from "@/lib/workflow-store"
import NodePalette from "@/components/workflow/node-palette"
import PropertiesPanel from "@/components/workflow/properties-panel"
import WorkflowCanvas from "@/components/workflow/workflow-canvas"
import Link from "next/link"
import { Moon, Sun, ChevronDown, ArrowLeft } from "lucide-react"
import { useTheme } from "next-themes"

export default function WorkflowBuilderPage() {
  const { classification, setClassification, name } = useWorkflowStore()
  const [mounted, setMounted] = useState(false)
  const { theme, setTheme } = useTheme()
  const [showClassificationDropdown, setShowClassificationDropdown] = useState(false)

  // Ensure components only render on client side
  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return (
      <div className="flex flex-col h-screen">
        <div className="w-full py-1 text-center text-white font-bold text-sm bg-green">
          UNCLASSIFIED - WRAITH PLATFORM
        </div>
        <div className="flex-1 flex items-center justify-center">
          <div className="animate-pulse flex space-x-4">
            <div className="rounded-full bg-muted h-10 w-10"></div>
            <div className="flex-1 space-y-4 py-1">
              <div className="h-4 bg-muted rounded w-3/4"></div>
              <div className="space-y-2">
                <div className="h-4 bg-muted rounded"></div>
                <div className="h-4 bg-muted rounded w-5/6"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="flex flex-col h-screen">
      <ClassificationBanner classification={classification} showInfoIcon={true} />

      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur">
        <div className="container flex h-14 items-center justify-between">
          <div className="flex items-center gap-2">
            <Link
              href="/platform"
              className="flex items-center gap-1 text-muted-foreground hover:text-foreground transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              <span className="text-sm">Back</span>
            </Link>

            <div className="h-6 w-px bg-border mx-2" />

            <Link href="/" className="flex items-center gap-2">
              <GhostIcon size={16} />
              <span className="text-base font-bold">WRAITH</span>
            </Link>

            <div className="h-6 w-px bg-border mx-2" />

            <div className="text-sm font-medium">Workflow Builder</div>

            <div className="h-6 w-px bg-border mx-2" />

            <div className="text-sm text-muted-foreground max-w-[200px] truncate" title={name}>
              {name}
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="relative">
              <button
                className="flex items-center gap-2 text-sm border rounded-md px-2.5 py-1.5 hover:bg-muted transition-colors"
                onClick={() => setShowClassificationDropdown(!showClassificationDropdown)}
              >
                <span className="text-xs font-medium">Classification: {classification.toUpperCase()}</span>
                <ChevronDown className="w-3.5 h-3.5" />
              </button>

              {showClassificationDropdown && (
                <div className="absolute right-0 mt-1 w-48 rounded-md shadow-lg bg-popover border z-50">
                  <div className="py-1">
                    <button
                      className="block px-4 py-2 text-sm w-full text-left hover:bg-muted transition-colors"
                      onClick={() => {
                        setClassification("unclassified")
                        setShowClassificationDropdown(false)
                      }}
                    >
                      UNCLASSIFIED
                    </button>
                    <button
                      className="block px-4 py-2 text-sm w-full text-left hover:bg-muted transition-colors"
                      onClick={() => {
                        setClassification("cui")
                        setShowClassificationDropdown(false)
                      }}
                    >
                      CUI
                    </button>
                    <button
                      className="block px-4 py-2 text-sm w-full text-left hover:bg-muted transition-colors"
                      onClick={() => {
                        setClassification("confidential")
                        setShowClassificationDropdown(false)
                      }}
                    >
                      CONFIDENTIAL
                    </button>
                    <button
                      className="block px-4 py-2 text-sm w-full text-left hover:bg-muted transition-colors"
                      onClick={() => {
                        setClassification("secret")
                        setShowClassificationDropdown(false)
                      }}
                    >
                      SECRET
                    </button>
                    <button
                      className="block px-4 py-2 text-sm w-full text-left hover:bg-muted transition-colors"
                      onClick={() => {
                        setClassification("topsecret")
                        setShowClassificationDropdown(false)
                      }}
                    >
                      TOP SECRET
                    </button>
                  </div>
                </div>
              )}
            </div>

            <button
              onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
              className="border rounded-md w-8 h-8 flex items-center justify-center hover:bg-muted transition-colors"
              aria-label="Toggle theme"
            >
              <Sun className="h-4 w-4 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
              <Moon className="absolute h-4 w-4 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
              <span className="sr-only">Toggle theme</span>
            </button>
          </div>
        </div>
      </header>

      <div className="flex-1 flex overflow-hidden">
        <div className="w-64 overflow-hidden">
          <NodePalette />
        </div>

        <div className="flex-1 overflow-hidden">
          <WorkflowCanvas />
        </div>

        <div className="w-80 overflow-hidden">
          <PropertiesPanel />
        </div>
      </div>

      <ClassificationBanner classification={classification} />
    </div>
  )
}
