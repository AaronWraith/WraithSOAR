"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Moon, Sun, Plus, Search, Filter } from "lucide-react"
import { useTheme } from "next-themes"
import { GhostIcon } from "@/components/icons/ghost-icon"
import { ClassificationBanner } from "@/components/classification-banner"

// Sample workflow data
const SAMPLE_WORKFLOWS = [
  {
    id: "wf-1",
    name: "Phishing Response",
    description: "Automated response to phishing emails",
    classification: "unclassified",
    status: "active",
    lastModified: "2023-12-10T14:30:00Z",
    creator: "John Smith",
  },
  {
    id: "wf-2",
    name: "Malware Analysis",
    description: "Automated malware analysis workflow",
    classification: "cui",
    status: "active",
    lastModified: "2023-12-09T10:15:00Z",
    creator: "Sarah Johnson",
  },
  {
    id: "wf-3",
    name: "Cross-Domain Transfer",
    description: "Secure data transfer across classification boundaries",
    classification: "secret",
    status: "draft",
    lastModified: "2023-12-08T16:45:00Z",
    creator: "Michael Brown",
  },
  {
    id: "wf-4",
    name: "Incident Response",
    description: "Standard incident response procedures",
    classification: "confidential",
    status: "active",
    lastModified: "2023-12-07T09:20:00Z",
    creator: "Emily Davis",
  },
  {
    id: "wf-5",
    name: "Threat Hunting",
    description: "Proactive threat hunting workflow",
    classification: "secret",
    status: "inactive",
    lastModified: "2023-12-06T13:10:00Z",
    creator: "Robert Wilson",
  },
]

export default function PlatformPage() {
  const [classification, setClassification] = useState<
    "unclassified" | "cui" | "confidential" | "secret" | "topsecret"
  >("unclassified")
  const [mounted, setMounted] = useState(false)
  const { theme, setTheme } = useTheme()

  // Ensure theme toggle only renders on client side
  useEffect(() => {
    setMounted(true)
  }, [])

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    })
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
      case "draft":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300"
      case "inactive":
        return "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300"
      default:
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300"
    }
  }

  const getClassificationColor = (classification: string) => {
    switch (classification) {
      case "cui":
        return "text-blue-600 dark:text-blue-400"
      case "confidential":
        return "text-purple-600 dark:text-purple-400"
      case "secret":
        return "text-red-600 dark:text-red-400"
      case "topsecret":
        return "text-black dark:text-white font-bold"
      default:
        return "text-green-600 dark:text-green-400"
    }
  }

  return (
    <div className="flex min-h-screen flex-col">
      <ClassificationBanner classification={classification} showInfoIcon={true} />

      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <Link href="/" className="flex items-center gap-2">
              <GhostIcon size={20} />
              <span className="text-xl font-bold">WRAITH</span>
            </Link>
          </div>

          <nav className="hidden md:flex items-center gap-6">
            <Link href="/platform" className="text-sm font-medium text-foreground">
              Workflows
            </Link>
            <Link
              href="/platform/dashboard"
              className="text-sm font-medium text-muted-foreground hover:text-foreground"
            >
              Dashboard
            </Link>
            <Link
              href="/platform/integrations"
              className="text-sm font-medium text-muted-foreground hover:text-foreground"
            >
              Integrations
            </Link>
            <Link href="/platform/settings" className="text-sm font-medium text-muted-foreground hover:text-foreground">
              Settings
            </Link>
          </nav>

          <div className="flex items-center gap-4">
            {mounted && (
              <button
                onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
                className="border rounded-md w-9 h-9 flex items-center justify-center"
                aria-label="Toggle theme"
              >
                <Sun className="h-4 w-4 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
                <Moon className="absolute h-4 w-4 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
                <span className="sr-only">Toggle theme</span>
              </button>
            )}
            <select
              className="border rounded px-2 py-1 text-sm bg-background"
              value={classification}
              onChange={(e) => setClassification(e.target.value as any)}
            >
              <option value="unclassified">UNCLASSIFIED</option>
              <option value="cui">CUI</option>
              <option value="confidential">CONFIDENTIAL</option>
              <option value="secret">SECRET</option>
              <option value="topsecret">TOP SECRET</option>
            </select>
          </div>
        </div>
      </header>

      <main className="flex-1 py-8">
        <div className="container">
          <div className="flex justify-between items-center mb-8">
            <h1 className="text-3xl font-bold">Workflows</h1>
            <Link
              href="/platform/workflows"
              className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-md"
            >
              <Plus className="w-4 h-4" />
              <span>New Workflow</span>
            </Link>
          </div>

          <div className="flex justify-between items-center mb-6">
            <div className="relative w-64">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <input
                type="text"
                placeholder="Search workflows..."
                className="pl-10 pr-4 py-2 w-full border rounded-md bg-background"
              />
            </div>

            <button className="flex items-center gap-2 px-3 py-2 border rounded-md">
              <Filter className="w-4 h-4" />
              <span>Filter</span>
            </button>
          </div>

          <div className="border rounded-md overflow-hidden">
            <table className="w-full">
              <thead>
                <tr className="bg-muted/50">
                  <th className="px-4 py-3 text-left text-sm font-medium">Name</th>
                  <th className="px-4 py-3 text-left text-sm font-medium">Classification</th>
                  <th className="px-4 py-3 text-left text-sm font-medium">Status</th>
                  <th className="px-4 py-3 text-left text-sm font-medium">Last Modified</th>
                  <th className="px-4 py-3 text-left text-sm font-medium">Created By</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {SAMPLE_WORKFLOWS.map((workflow) => (
                  <tr key={workflow.id} className="hover:bg-muted/30">
                    <td className="px-4 py-4">
                      <Link href={`/platform/workflows?id=${workflow.id}`} className="font-medium hover:underline">
                        {workflow.name}
                      </Link>
                      <p className="text-sm text-muted-foreground">{workflow.description}</p>
                    </td>
                    <td className="px-4 py-4">
                      <span className={getClassificationColor(workflow.classification)}>
                        {workflow.classification.toUpperCase()}
                      </span>
                    </td>
                    <td className="px-4 py-4">
                      <span className={`px-2 py-1 rounded-full text-xs ${getStatusColor(workflow.status)}`}>
                        {workflow.status.charAt(0).toUpperCase() + workflow.status.slice(1)}
                      </span>
                    </td>
                    <td className="px-4 py-4 text-sm">{formatDate(workflow.lastModified)}</td>
                    <td className="px-4 py-4 text-sm">{workflow.creator}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </main>

      <ClassificationBanner classification={classification} />
    </div>
  )
}
