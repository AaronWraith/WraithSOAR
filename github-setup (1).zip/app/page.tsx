import Link from "next/link"
import { GhostIcon } from "@/components/icons/ghost-icon"
import { Shield, Zap, Lock, Globe, Brain, LayoutDashboard } from "lucide-react"

export default function HomePage() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <Link href="/" className="flex items-center gap-2">
              <GhostIcon size={20} />
              <span className="text-xl font-bold">WRAITH</span>
            </Link>
          </div>

          <nav className="hidden md:flex items-center gap-6">
            <Link href="/features" className="text-sm font-medium text-muted-foreground hover:text-foreground">
              Features
            </Link>
            <Link href="/solutions" className="text-sm font-medium text-muted-foreground hover:text-foreground">
              Solutions
            </Link>
            <Link href="/pricing" className="text-sm font-medium text-muted-foreground hover:text-foreground">
              Pricing
            </Link>
            <Link href="/docs" className="text-sm font-medium text-muted-foreground hover:text-foreground">
              Documentation
            </Link>
          </nav>

          <div className="flex items-center gap-4">
            <Link
              href="/platform"
              className="px-4 py-2 rounded-md bg-primary text-primary-foreground font-medium text-sm"
            >
              Launch Platform
            </Link>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative py-20 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-background via-background to-accent/20 z-0"></div>
          <div className="container relative z-10">
            <div className="flex flex-col items-center text-center max-w-3xl mx-auto">
              <div className="mb-4 px-3 py-1 text-sm bg-[#39FF14]/10 text-[#39FF14] border border-[#39FF14]/20 rounded-full">
                MILITARY-GRADE SECURITY
              </div>
              <h1 className="text-4xl md:text-6xl font-bold mb-6">
                Security Orchestration for the <span className="text-[#39FF14]">Modern Battlefield</span>
              </h1>
              <p className="text-xl text-muted-foreground mb-8">
                WRAITH SOAR platform delivers military-grade security automation with air-gapped deployment options and
                compliance with the strictest DOD requirements.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/platform" className="px-8 py-3 rounded-md bg-primary text-primary-foreground font-medium">
                  Try Demo
                </Link>
                <Link
                  href="/docs"
                  className="px-8 py-3 rounded-md bg-transparent border border-input text-foreground font-medium"
                >
                  View Documentation
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-20 bg-accent/5" id="features">
          <div className="container">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold mb-4">Military-Grade Security Automation</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                WRAITH combines advanced orchestration capabilities with DOD-specific security controls
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[
                {
                  icon: Shield,
                  title: "DOD Compliance",
                  description:
                    "Built from the ground up to meet NIST 800-53, DISA STIGs, and DOD Zero Trust requirements",
                },
                {
                  icon: Zap,
                  title: "Air-Gapped Deployment",
                  description: "Fully functional in disconnected environments with no external dependencies",
                },
                {
                  icon: Lock,
                  title: "Classification Controls",
                  description: "Enforce data handling based on classification levels from UNCLASSIFIED to TOP SECRET",
                },
                {
                  icon: Globe,
                  title: "Cross-Domain Solutions",
                  description: "Secure workflows across classification boundaries with proper guards and controls",
                },
                {
                  icon: Brain,
                  title: "AI Integration",
                  description: "Leverage AI capabilities while maintaining strict security and data sovereignty",
                },
                {
                  icon: LayoutDashboard,
                  title: "Visual Workflow Builder",
                  description: "Intuitive drag-and-drop interface for building complex security workflows",
                },
              ].map((feature, index) => (
                <div key={index} className="rounded-lg border bg-card p-6 shadow-sm">
                  <div className="mb-4 text-primary">
                    <feature.icon size={32} />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                  <p className="text-muted-foreground">{feature.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-gradient-to-br from-black to-zinc-900">
          <div className="container">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-white">
                Ready to Modernize Your Security Operations?
              </h2>
              <p className="text-xl text-gray-300 mb-8">
                Join the elite organizations that trust WRAITH SOAR for their most critical security operations.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link
                  href="/contact"
                  className="px-8 py-3 rounded-md bg-[#39FF14] text-black font-medium hover:bg-[#39FF14]/90"
                >
                  Request a Demo
                </Link>
                <Link
                  href="/docs"
                  className="px-8 py-3 rounded-md border border-white/20 text-white hover:bg-white/10 font-medium"
                >
                  View Documentation
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-background border-t py-12">
        <div className="container">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center gap-2 mb-4 md:mb-0">
              <GhostIcon size={20} />
              <span className="text-xl font-bold">WRAITH</span>
            </div>
            <div className="flex gap-8">
              <Link href="/about" className="text-sm text-muted-foreground hover:text-foreground">
                About
              </Link>
              <Link href="/contact" className="text-sm text-muted-foreground hover:text-foreground">
                Contact
              </Link>
              <Link href="/privacy" className="text-sm text-muted-foreground hover:text-foreground">
                Privacy
              </Link>
              <Link href="/terms" className="text-sm text-muted-foreground hover:text-foreground">
                Terms
              </Link>
            </div>
          </div>
          <div className="mt-8 text-center text-sm text-muted-foreground">
            © 2023 WRAITH Security. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  )
}
