import Link from "next/link"
import { Shield, Building2, Server, Globe, Database, Lock } from "lucide-react"
import { GhostIcon } from "@/components/icons/ghost-icon"
import { ClassificationBanner } from "@/components/classification-banner"

export default function SolutionsPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <ClassificationBanner classification="unclassified" />

      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <Link href="/" className="flex items-center gap-2">
              <GhostIcon size={20} />
              <span className="text-xl font-bold">WRAITH</span>
            </Link>
          </div>

          <nav className="hidden md:flex items-center gap-6">
            <Link href="/features" className="text-sm font-medium text-muted-foreground hover:text-foreground">
              Features
            </Link>
            <Link href="/solutions" className="text-sm font-medium text-foreground">
              Solutions
            </Link>
            <Link href="/pricing" className="text-sm font-medium text-muted-foreground hover:text-foreground">
              Pricing
            </Link>
            <Link href="/docs" className="text-sm font-medium text-muted-foreground hover:text-foreground">
              Documentation
            </Link>
          </nav>

          <div className="flex items-center gap-4">
            <Link
              href="/platform"
              className="px-4 py-2 rounded-md bg-primary text-primary-foreground font-medium text-sm"
            >
              Launch Platform
            </Link>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="py-20 bg-gradient-to-b from-background to-muted/20">
          <div className="container">
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-6">Security Solutions for Every Sector</h1>
              <p className="text-xl text-muted-foreground mb-8">
                From defense agencies to commercial enterprises, WRAITH SOAR adapts to your unique security challenges
              </p>
            </div>
          </div>
        </section>

        {/* Industry Solutions Section */}
        <section className="py-20">
          <div className="container">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
              <div className="rounded-lg border bg-card overflow-hidden">
                <div className="h-48 bg-gradient-to-r from-blue-600 to-blue-800 flex items-center justify-center">
                  <Shield size={64} className="text-white" />
                </div>
                <div className="p-8">
                  <h3 className="text-2xl font-semibold mb-4">Defense & Intelligence</h3>
                  <p className="text-muted-foreground mb-6">
                    Secure solutions for military, intelligence agencies, and defense contractors with classification
                    controls and air-gapped deployment options. WRAITH SOAR is designed to meet the unique requirements
                    of defense organizations.
                  </p>
                  <ul className="space-y-2 mb-6">
                    <li className="flex items-start gap-2">
                      <span className="text-green-500 mt-1">✓</span>
                      <span>Classification-aware workflows and data handling</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-green-500 mt-1">✓</span>
                      <span>Air-gapped deployment with no external dependencies</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-green-500 mt-1">✓</span>
                      <span>Cross-domain solutions with proper security controls</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-green-500 mt-1">✓</span>
                      <span>Compliance with NIST 800-53, DISA STIGs, and RMF</span>
                    </li>
                  </ul>
                  <Link href="/solutions/defense" className="text-primary hover:underline font-medium">
                    Learn more about Defense & Intelligence solutions →
                  </Link>
                </div>
              </div>

              <div className="rounded-lg border bg-card overflow-hidden">
                <div className="h-48 bg-gradient-to-r from-emerald-600 to-emerald-800 flex items-center justify-center">
                  <Building2 size={64} className="text-white" />
                </div>
                <div className="p-8">
                  <h3 className="text-2xl font-semibold mb-4">Enterprise Security</h3>
                  <p className="text-muted-foreground mb-6">
                    Military-grade security for enterprises with advanced threat detection, automated response, and
                    compliance reporting. Protect your organization with the same technology trusted by defense
                    agencies.
                  </p>
                  <ul className="space-y-2 mb-6">
                    <li className="flex items-start gap-2">
                      <span className="text-green-500 mt-1">✓</span>
                      <span>Automated incident response and threat hunting</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-green-500 mt-1">✓</span>
                      <span>Integration with existing security tools and infrastructure</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-green-500 mt-1">✓</span>
                      <span>Compliance reporting for SOC 2, ISO 27001, and more</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-green-500 mt-1">✓</span>
                      <span>Scalable deployment options for growing organizations</span>
                    </li>
                  </ul>
                  <Link href="/solutions/enterprise" className="text-primary hover:underline font-medium">
                    Learn more about Enterprise Security solutions →
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Use Cases Section */}
        <section className="py-20 bg-muted/20">
          <div className="container">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold mb-4">Key Use Cases</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                WRAITH SOAR addresses a wide range of security challenges across different sectors
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[
                {
                  icon: Server,
                  title: "Incident Response",
                  description:
                    "Automate incident response workflows to reduce mean time to detect and respond to security incidents",
                },
                {
                  icon: Globe,
                  title: "Threat Hunting",
                  description:
                    "Proactively search for threats in your environment with automated hunting playbooks and intelligence",
                },
                {
                  icon: Database,
                  title: "Vulnerability Management",
                  description: "Streamline vulnerability scanning, prioritization, and remediation workflows",
                },
                {
                  icon: Lock,
                  title: "Security Compliance",
                  description: "Automate compliance checks and reporting for various regulatory frameworks",
                },
                {
                  icon: Shield,
                  title: "Alert Triage",
                  description:
                    "Automatically enrich, correlate, and prioritize security alerts to reduce alert fatigue",
                },
                {
                  icon: Building2,
                  title: "Security Operations",
                  description: "Centralize and automate day-to-day security operations and routine tasks",
                },
              ].map((useCase, index) => (
                <div key={index} className="rounded-lg border bg-card p-6 shadow-sm">
                  <div className="mb-4 text-primary">
                    <useCase.icon size={32} />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{useCase.title}</h3>
                  <p className="text-muted-foreground">{useCase.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Deployment Options Section */}
        <section className="py-20">
          <div className="container">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold mb-4">Flexible Deployment Options</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Choose the deployment model that best fits your security requirements
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="rounded-lg border bg-card p-6 shadow-sm">
                <h3 className="text-xl font-semibold mb-4">On-Premises</h3>
                <p className="text-muted-foreground mb-4">
                  Full control over your deployment with on-premises installation within your security boundary
                </p>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-start gap-2">
                    <span className="text-green-500 mt-1">✓</span>
                    <span>Complete data sovereignty</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-500 mt-1">✓</span>
                    <span>Air-gapped environments</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-500 mt-1">✓</span>
                    <span>Custom hardware configurations</span>
                  </li>
                </ul>
              </div>

              <div className="rounded-lg border bg-card p-6 shadow-sm">
                <h3 className="text-xl font-semibold mb-4">Private Cloud</h3>
                <p className="text-muted-foreground mb-4">
                  Deploy in your private cloud environment for enhanced security and control
                </p>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-start gap-2">
                    <span className="text-green-500 mt-1">✓</span>
                    <span>AWS, Azure, or GCP deployment</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-500 mt-1">✓</span>
                    <span>VPC isolation</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-500 mt-1">✓</span>
                    <span>Scalable resources</span>
                  </li>
                </ul>
              </div>

              <div className="rounded-lg border bg-card p-6 shadow-sm">
                <h3 className="text-xl font-semibold mb-4">Hybrid</h3>
                <p className="text-muted-foreground mb-4">
                  Combine on-premises and cloud components for maximum flexibility
                </p>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-start gap-2">
                    <span className="text-green-500 mt-1">✓</span>
                    <span>Distributed architecture</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-500 mt-1">✓</span>
                    <span>Cross-environment workflows</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-green-500 mt-1">✓</span>
                    <span>Flexible scaling</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-gradient-to-br from-black to-zinc-900">
          <div className="container">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-white">
                Find the Right Solution for Your Organization
              </h2>
              <p className="text-xl text-gray-300 mb-8">
                Our security experts will help you identify the best solution for your specific requirements
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link
                  href="/contact"
                  className="px-8 py-3 rounded-md bg-[#39FF14] text-black font-medium hover:bg-[#39FF14]/90"
                >
                  Schedule a Consultation
                </Link>
                <Link
                  href="/platform"
                  className="px-8 py-3 rounded-md border border-white/20 text-white hover:bg-white/10 font-medium"
                >
                  Try Demo
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-background border-t py-12">
        <div className="container">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center gap-2 mb-4 md:mb-0">
              <GhostIcon className="text-[#39FF14]" size={20} />
              <span className="text-xl font-bold">WRAITH</span>
            </div>
            <div className="flex gap-8">
              <Link href="/about" className="text-sm text-muted-foreground hover:text-foreground">
                About
              </Link>
              <Link href="/contact" className="text-sm text-muted-foreground hover:text-foreground">
                Contact
              </Link>
              <Link href="/privacy" className="text-sm text-muted-foreground hover:text-foreground">
                Privacy
              </Link>
              <Link href="/terms" className="text-sm text-muted-foreground hover:text-foreground">
                Terms
              </Link>
            </div>
          </div>
          <div className="mt-8 text-center text-sm text-muted-foreground">
            © 2023 WRAITH Security. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  )
}
