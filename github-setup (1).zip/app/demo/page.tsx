"use client"

import { useState } from "react"
import { ClassificationBanner } from "@/components/classification-banner"
import Link from "next/link"
import { GhostIcon } from "@/components/icons/ghost-icon"

export default function DemoPage() {
  const [classification, setClassification] = useState<
    "unclassified" | "cui" | "confidential" | "secret" | "topsecret"
  >("unclassified")

  return (
    <div className="flex min-h-screen flex-col">
      <ClassificationBanner classification={classification} showInfoIcon={true} />

      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <Link href="/" className="flex items-center gap-2">
              <GhostIcon size={20} />
              <span className="text-xl font-bold">WRAITH</span>
            </Link>
          </div>

          <nav className="hidden md:flex items-center gap-6">
            <Link href="/" className="text-sm font-medium text-muted-foreground hover:text-foreground">
              Home
            </Link>
          </nav>

          <div className="flex items-center gap-4">
            <select
              className="border rounded px-2 py-1 text-sm bg-background"
              value={classification}
              onChange={(e) => setClassification(e.target.value as any)}
            >
              <option value="unclassified">UNCLASSIFIED</option>
              <option value="cui">CUI</option>
              <option value="confidential">CONFIDENTIAL</option>
              <option value="secret">SECRET</option>
              <option value="topsecret">TOP SECRET</option>
            </select>
          </div>
        </div>
      </header>

      <main className="flex-1 p-8">
        <h1 className="text-3xl font-bold mb-4">Demo Page</h1>
        <p className="mb-4">This is a simple demo page to test if the imports are working correctly.</p>
        <Link href="/" className="text-primary hover:underline">
          Back to Home
        </Link>
      </main>

      <ClassificationBanner classification={classification} />
    </div>
  )
}
