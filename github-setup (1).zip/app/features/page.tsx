import Link from "next/link"
import {
  Shield,
  Zap,
  Lock,
  Globe,
  Brain,
  LayoutDashboard,
  Workflow,
  FileSearch,
  Bell,
  BarChart3,
  Users,
  Server,
} from "lucide-react"
import { GhostIcon } from "@/components/icons/ghost-icon"
import { ClassificationBanner } from "@/components/classification-banner"

export default function FeaturesPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <ClassificationBanner classification="unclassified" />

      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <Link href="/" className="flex items-center gap-2">
              <GhostIcon size={20} />
              <span className="text-xl font-bold">WRAITH</span>
            </Link>
          </div>

          <nav className="hidden md:flex items-center gap-6">
            <Link href="/features" className="text-sm font-medium text-foreground">
              Features
            </Link>
            <Link href="/solutions" className="text-sm font-medium text-muted-foreground hover:text-foreground">
              Solutions
            </Link>
            <Link href="/pricing" className="text-sm font-medium text-muted-foreground hover:text-foreground">
              Pricing
            </Link>
            <Link href="/docs" className="text-sm font-medium text-muted-foreground hover:text-foreground">
              Documentation
            </Link>
          </nav>

          <div className="flex items-center gap-4">
            <Link
              href="/platform"
              className="px-4 py-2 rounded-md bg-primary text-primary-foreground font-medium text-sm"
            >
              Launch Platform
            </Link>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="py-20 bg-gradient-to-b from-background to-muted/20">
          <div className="container">
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-6">
                Military-Grade Security Features for Modern Threats
              </h1>
              <p className="text-xl text-muted-foreground mb-8">
                WRAITH SOAR combines advanced orchestration capabilities with DOD-specific security controls to deliver
                unparalleled protection for your organization.
              </p>
            </div>
          </div>
        </section>

        {/* Core Features Section */}
        <section className="py-20">
          <div className="container">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold mb-4">Core Platform Features</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                WRAITH SOAR provides a comprehensive set of features to automate and orchestrate your security
                operations
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[
                {
                  icon: LayoutDashboard,
                  title: "Visual Workflow Builder",
                  description:
                    "Intuitive drag-and-drop interface for building complex security workflows without coding",
                },
                {
                  icon: Workflow,
                  title: "Automated Playbooks",
                  description:
                    "Pre-built and customizable playbooks for common security scenarios and compliance frameworks",
                },
                {
                  icon: FileSearch,
                  title: "Threat Intelligence",
                  description: "Integration with leading threat intelligence platforms and custom intelligence sources",
                },
                {
                  icon: Bell,
                  title: "Alert Management",
                  description: "Centralized alert collection, deduplication, enrichment, and automated triage",
                },
                {
                  icon: BarChart3,
                  title: "Analytics & Reporting",
                  description:
                    "Comprehensive dashboards and reports for security metrics, compliance, and executive summaries",
                },
                {
                  icon: Users,
                  title: "Collaboration Tools",
                  description:
                    "Built-in case management, commenting, and team collaboration features for incident response",
                },
              ].map((feature, index) => (
                <div key={index} className="rounded-lg border bg-card p-6 shadow-sm">
                  <div className="mb-4 text-primary">
                    <feature.icon size={32} />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                  <p className="text-muted-foreground">{feature.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Military-Grade Security Section */}
        <section className="py-20 bg-muted/20">
          <div className="container">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold mb-4">Military-Grade Security</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                WRAITH SOAR is built from the ground up to meet the strictest security requirements
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[
                {
                  icon: Shield,
                  title: "DOD Compliance",
                  description:
                    "Built to meet NIST 800-53, DISA STIGs, and DOD Zero Trust requirements with comprehensive controls",
                },
                {
                  icon: Zap,
                  title: "Air-Gapped Deployment",
                  description:
                    "Fully functional in disconnected environments with no external dependencies or cloud requirements",
                },
                {
                  icon: Lock,
                  title: "Classification Controls",
                  description:
                    "Enforce data handling based on classification levels from UNCLASSIFIED to TOP SECRET with visual indicators",
                },
                {
                  icon: Globe,
                  title: "Cross-Domain Solutions",
                  description:
                    "Secure workflows across classification boundaries with proper guards and data validation controls",
                },
                {
                  icon: Brain,
                  title: "Secure AI Integration",
                  description:
                    "Leverage AI capabilities while maintaining strict security and data sovereignty requirements",
                },
                {
                  icon: Server,
                  title: "On-Premises Architecture",
                  description:
                    "Complete control over your deployment with on-premises options that keep your data within your security boundary",
                },
              ].map((feature, index) => (
                <div key={index} className="rounded-lg border bg-card p-6 shadow-sm">
                  <div className="mb-4 text-primary">
                    <feature.icon size={32} />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                  <p className="text-muted-foreground">{feature.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Integration Section */}
        <section className="py-20">
          <div className="container">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold mb-4">Extensive Integration Ecosystem</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Connect with your existing security tools and infrastructure
              </p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              {[
                "SIEM & Log Management",
                "EDR & Endpoint Security",
                "Firewalls & Network Security",
                "Threat Intelligence",
                "Vulnerability Management",
                "Email Security",
                "Cloud Security",
                "Identity & Access Management",
                "Ticketing Systems",
                "Communication Tools",
                "Custom APIs",
                "Data Sources",
              ].map((integration, index) => (
                <div
                  key={index}
                  className="rounded-lg border bg-card p-4 text-center hover:border-primary transition-colors"
                >
                  <p className="font-medium">{integration}</p>
                </div>
              ))}
            </div>

            <div className="mt-12 text-center">
              <Link href="/integrations" className="inline-flex items-center text-primary hover:underline font-medium">
                View all integrations →
              </Link>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-gradient-to-br from-black to-zinc-900">
          <div className="container">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-white">
                Ready to Transform Your Security Operations?
              </h2>
              <p className="text-xl text-gray-300 mb-8">
                Join the elite organizations that trust WRAITH SOAR for their most critical security operations.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link
                  href="/contact"
                  className="px-8 py-3 rounded-md bg-[#39FF14] text-black font-medium hover:bg-[#39FF14]/90"
                >
                  Request a Demo
                </Link>
                <Link
                  href="/pricing"
                  className="px-8 py-3 rounded-md border border-white/20 text-white hover:bg-white/10 font-medium"
                >
                  View Pricing
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-background border-t py-12">
        <div className="container">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center gap-2 mb-4 md:mb-0">
              <GhostIcon className="text-[#39FF14]" size={20} />
              <span className="text-xl font-bold">WRAITH</span>
            </div>
            <div className="flex gap-8">
              <Link href="/about" className="text-sm text-muted-foreground hover:text-foreground">
                About
              </Link>
              <Link href="/contact" className="text-sm text-muted-foreground hover:text-foreground">
                Contact
              </Link>
              <Link href="/privacy" className="text-sm text-muted-foreground hover:text-foreground">
                Privacy
              </Link>
              <Link href="/terms" className="text-sm text-muted-foreground hover:text-foreground">
                Terms
              </Link>
            </div>
          </div>
          <div className="mt-8 text-center text-sm text-muted-foreground">
            © 2023 WRAITH Security. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  )
}
