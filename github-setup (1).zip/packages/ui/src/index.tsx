// This file is intentionally empty to avoid import errors
// All components have been moved to the main project
