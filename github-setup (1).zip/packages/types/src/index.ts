// This file is intentionally empty to avoid import errors
// All types have been moved to the main project
