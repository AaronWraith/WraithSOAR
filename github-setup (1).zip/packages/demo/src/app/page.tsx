"use client"

import { useState } from "react"
import { ClassificationBanner } from "@wraith-soar/ui"
import { CLASSIFICATION_LEVELS } from "@wraith-soar/types"
import Link from "next/link"

export default function DemoPage() {
  const [classification, setClassification] = useState<
    "unclassified" | "cui" | "confidential" | "secret" | "topsecret"
  >("unclassified")

  return (
    <div className="flex min-h-screen flex-col">
      <ClassificationBanner classification={classification} showInfoIcon={true} />

      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <Link href="/" className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-black">
                <span className="text-[#39FF14]">W</span>
              </div>
              <span className="text-xl font-bold">WRAITH</span>
            </Link>
          </div>

          <nav className="hidden md:flex items-center gap-6">
            <Link href="#features" className="text-sm font-medium text-muted-foreground hover:text-foreground">
              Features
            </Link>
            <Link href="#solutions" className="text-sm font-medium text-muted-foreground hover:text-foreground">
              Solutions
            </Link>
            <Link href="#pricing" className="text-sm font-medium text-muted-foreground hover:text-foreground">
              Pricing
            </Link>
            <Link href="#docs" className="text-sm font-medium text-muted-foreground hover:text-foreground">
              Documentation
            </Link>
          </nav>

          <div className="flex items-center gap-4">
            <select
              className="border rounded px-2 py-1 text-sm bg-background"
              value={classification}
              onChange={(e) => setClassification(e.target.value as any)}
            >
              {CLASSIFICATION_LEVELS.map((level) => (
                <option key={level.id} value={level.id}>
                  {level.label}
                </option>
              ))}
            </select>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative py-20 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-background via-background to-accent/20 z-0"></div>
          <div className="container relative z-10">
            <div className="flex flex-col items-center text-center max-w-3xl mx-auto">
              <div className="mb-4 px-3 py-1 text-sm bg-[#39FF14]/10 text-[#39FF14] border border-[#39FF14]/20 rounded-full">
                INTERACTIVE DEMO
              </div>
              <h1 className="text-4xl md:text-5xl font-bold mb-6">Experience WRAITH SOAR in Action</h1>
              <p className="text-xl text-muted-foreground mb-8">
                This interactive demo showcases the key features of the WRAITH SOAR platform, including classification
                controls and workflow visualization.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <button className="px-8 py-3 rounded-md bg-primary text-primary-foreground font-medium">
                  Try Workflow Builder
                </button>
                <button className="px-8 py-3 rounded-md bg-transparent border border-input text-foreground font-medium">
                  View Documentation
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* Demo Workflow Section */}
        <section className="py-20 bg-accent/5">
          <div className="container">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold mb-4">Interactive Workflow Builder</h2>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Create powerful security automation workflows with our intuitive drag-and-drop interface
              </p>
            </div>

            <div className="border rounded-lg overflow-hidden shadow-lg">
              <div className="border-b p-4 flex justify-between items-center bg-muted/30">
                <div className="flex items-center gap-2">
                  <h3 className="font-medium">Phishing Response Workflow</h3>
                  <span className="px-2 py-0.5 rounded-full text-xs bg-muted">Draft</span>
                </div>
              </div>
              <div className="h-[500px] relative flex items-center justify-center bg-muted/10">
                <div className="text-center">
                  <p className="text-muted-foreground mb-4">
                    Workflow visualization would appear here in the full demo
                  </p>
                  <button className="px-4 py-2 rounded-md bg-primary text-primary-foreground font-medium text-sm">
                    Request Full Demo
                  </button>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <ClassificationBanner classification={classification} showInfoIcon={true} />
    </div>
  )
}
