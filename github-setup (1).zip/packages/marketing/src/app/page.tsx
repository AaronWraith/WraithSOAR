import { Button } from "@wraith-soar/ui"
import Link from "next/link"

export default function HomePage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative py-20 md:py-32 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-background via-background to-accent/20 z-0"></div>
        <div className="container relative z-10 mx-auto px-4">
          <div className="flex flex-col items-center text-center max-w-3xl mx-auto">
            <div className="mb-4 px-3 py-1 text-sm bg-[#39FF14]/10 text-[#39FF14] border border-[#39FF14]/20 rounded-full">
              DOD-APPROVED SECURITY AUTOMATION
            </div>
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Security Orchestration for the <span className="text-[#39FF14]">Modern Battlefield</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-8">
              WRAITH SOAR platform delivers military-grade security automation with air-gapped deployment options and
              compliance with the strictest DOD requirements.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" className="px-8">
                Request Demo
              </Button>
              <Button variant="outline" size="lg">
                View Documentation
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-accent/5">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">Military-Grade Security Automation</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              WRAITH combines advanced orchestration capabilities with DOD-specific security controls
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: "🛡️",
                title: "DOD Compliance",
                description:
                  "Built from the ground up to meet NIST 800-53, DISA STIGs, and DOD Zero Trust requirements",
              },
              {
                icon: "⚡",
                title: "Air-Gapped Deployment",
                description: "Fully functional in disconnected environments with no external dependencies",
              },
              {
                icon: "🔒",
                title: "Classification Controls",
                description: "Enforce data handling based on classification levels from UNCLASSIFIED to TOP SECRET",
              },
              {
                icon: "🌐",
                title: "Cross-Domain Solutions",
                description: "Secure workflows across classification boundaries with proper guards and controls",
              },
              {
                icon: "🖥️",
                title: "AI Integration",
                description: "Leverage AI capabilities while maintaining strict security and data sovereignty",
              },
              {
                icon: "📊",
                title: "Visual Workflow Builder",
                description: "Intuitive drag-and-drop interface for building complex security workflows",
              },
            ].map((feature, index) => (
              <div key={index} className="rounded-lg border bg-card p-6 shadow-sm">
                <div className="mb-4 text-4xl">{feature.icon}</div>
                <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-br from-black to-zinc-900">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-white">
              Ready to Modernize Your Security Operations?
            </h2>
            <p className="text-xl text-gray-300 mb-8">
              Join the elite organizations that trust WRAITH SOAR for their most critical security operations.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/contact">
                <Button size="lg" className="bg-[#39FF14] text-black hover:bg-[#39FF14]/90">
                  Request a Demo
                </Button>
              </Link>
              <Link href="/docs">
                <Button variant="outline" className="border-white/20 text-white hover:bg-white/10">
                  View Documentation
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
