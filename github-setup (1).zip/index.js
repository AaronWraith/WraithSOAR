// This file is intentionally empty
// The Next.js app is in the app directory
