# Contributing to WRAITH SOAR

Thank you for your interest in contributing to WRAITH SOAR! This document provides guidelines and instructions for contributing to this project.

## Code of Conduct

By participating in this project, you agree to abide by our Code of Conduct. Please read it before contributing.

## How Can I Contribute?

### Reporting Bugs

- Check if the bug has already been reported in the Issues section
- Use the bug report template to create a new issue
- Include detailed steps to reproduce the bug
- Include screenshots if applicable
- Describe the expected behavior and what actually happened

### Suggesting Enhancements

- Check if the enhancement has already been suggested in the Issues section
- Use the feature request template to create a new issue
- Provide a clear description of the enhancement
- Explain why this enhancement would be useful

### Pull Requests

1. Fork the repository
2. Create a new branch (`git checkout -b feature/amazing-feature`)
3. Make your changes
4. Run tests and linting (`npm run test && npm run lint`)
5. Commit your changes (`git commit -m 'Add some amazing feature'`)
6. Push to the branch (`git push origin feature/amazing-feature`)
7. Open a Pull Request

## Development Setup

1. Clone the repository
2. Install dependencies with `npm install`
3. Start the development server with `npm run dev:marketing` or `npm run dev:demo`

## Coding Guidelines

- Follow the existing code style
- Write tests for new features
- Update documentation for changes
- Keep pull requests focused on a single topic
- Use descriptive commit messages

## Security Considerations

- Do not commit sensitive information (API keys, credentials, etc.)
- Do not include actual implementation details of security-critical components
- Follow the security boundaries defined in the README

## License

By contributing to WRAITH SOAR, you agree that your contributions will be licensed under the project's MIT License.
\`\`\`

Let's create a LICENSE file:
