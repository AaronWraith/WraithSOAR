export type ClassificationLevel = "unclassified" | "cui" | "confidential" | "secret" | "topsecret"

export interface ClassificationInfo {
  id: ClassificationLevel
  label: string
  color: string
  description: string
}

export const CLASSIFICATION_LEVELS: ClassificationInfo[] = [
  {
    id: "unclassified",
    label: "UNCLASSIFIED",
    color: "green",
    description: "Information that can be lawfully obtained by the general public",
  },
  {
    id: "cui",
    label: "CUI",
    color: "blue",
    description: "Controlled Unclassified Information that requires safeguarding or dissemination controls",
  },
  {
    id: "confidential",
    label: "CONFIDENTIAL",
    color: "purple",
    description: "Information that could reasonably be expected to cause damage to national security",
  },
  {
    id: "secret",
    label: "SECRET",
    color: "red",
    description: "Information that could reasonably be expected to cause serious damage to national security",
  },
  {
    id: "topsecret",
    label: "TOP SECRET",
    color: "black",
    description:
      "Information that could reasonably be expected to cause exceptionally grave damage to national security",
  },
]

export function getClassificationInfo(classification: ClassificationLevel): ClassificationInfo {
  return CLASSIFICATION_LEVELS.find((level) => level.id === classification) || CLASSIFICATION_LEVELS[0]
}
