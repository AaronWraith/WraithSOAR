/**
 * Public type definitions for classification levels.
 * These are safe to share as they don't contain implementation details.
 */

export type ClassificationLevel = "unclassified" | "cui" | "confidential" | "secret" | "topsecret"

export interface ClassificationInfo {
  id: ClassificationLevel
  label: string
  color: string
}

export const CLASSIFICATION_LEVELS: ClassificationInfo[] = [
  { id: "unclassified", label: "UNCLASSIFIED", color: "green" },
  { id: "cui", label: "CUI", color: "blue" },
  { id: "confidential", label: "CONFIDENTIAL", color: "purple" },
  { id: "secret", label: "SECRET", color: "red" },
  { id: "topsecret", label: "TOP SECRET", color: "black" },
]

/**
 * Public type definitions for workflow components.
 * These are safe to share as they don't contain implementation details.
 */

export interface NodeData {
  id: string
  type: string
  position: {
    x: number
    y: number
  }
  data: {
    label: string
    [key: string]: any
  }
}

export interface EdgeData {
  id: string
  source: string
  target: string
  sourceHandle?: string
  targetHandle?: string
}

export interface WorkflowData {
  nodes: NodeData[]
  edges: EdgeData[]
  name: string
  description: string
  classification: string
  creator: {
    id: string
    username: string
  }
  lastModified: {
    timestamp: string
    userId: string
    username: string
  }
  approvalStatus: "draft" | "pending_approval" | "approved" | "rejected"
  version: number
  tags: string[]
}

// Public interfaces for validation
export type ValidationSeverity = "error" | "warning" | "info"

export interface ValidationError {
  id: string
  nodeId?: string
  message: string
  severity: ValidationSeverity
}

export interface ValidationResult {
  isValid: boolean
  errors: ValidationError[]
}
