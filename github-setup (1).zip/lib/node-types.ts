export interface NodeTypeInfo {
  type: string
  category: string
  label: string
  description: string
  icon: string
  inputs: number
  outputs: number
  color: string
  configFields: ConfigField[]
}

export interface ConfigField {
  name: string
  label: string
  type: "text" | "select" | "number" | "boolean" | "textarea" | "code"
  required?: boolean
  placeholder?: string
  options?: { value: string; label: string }[]
  defaultValue?: any
}

// Define CLASSIFICATION_LEVELS here
const CLASSIFICATION_LEVELS = [
  { id: "unclassified", label: "Unclassified" },
  { id: "confidential", label: "Confidential" },
  { id: "secret", label: "Secret" },
  { id: "top_secret", label: "Top Secret" },
]

export const NODE_TYPES: NodeTypeInfo[] = [
  // Triggers
  {
    type: "emailTrigger",
    category: "triggers",
    label: "Email Trigger",
    description: "Triggers workflow when an email is received",
    icon: "mail",
    inputs: 0,
    outputs: 1,
    color: "#3b82f6",
    configFields: [
      {
        name: "mailbox",
        label: "Mailbox",
        type: "text",
        required: true,
        placeholder: "security@example.mil",
      },
      {
        name: "subjectFilter",
        label: "Subject Filter",
        type: "text",
        placeholder: "[ALERT]",
      },
    ],
  },
  {
    type: "scheduleTrigger",
    category: "triggers",
    label: "Schedule",
    description: "Triggers workflow on a schedule",
    icon: "clock",
    inputs: 0,
    outputs: 1,
    color: "#3b82f6",
    configFields: [
      {
        name: "schedule",
        label: "CRON Schedule",
        type: "text",
        required: true,
        placeholder: "0 * * * *",
      },
    ],
  },
  {
    type: "webhookTrigger",
    category: "triggers",
    label: "Webhook",
    description: "Triggers workflow when a webhook is received",
    icon: "webhook",
    inputs: 0,
    outputs: 1,
    color: "#3b82f6",
    configFields: [
      {
        name: "path",
        label: "Path",
        type: "text",
        required: true,
        placeholder: "/hooks/security-alert",
      },
    ],
  },

  // Analysis
  {
    type: "threatIntel",
    category: "analysis",
    label: "Threat Intel",
    description: "Enriches data with threat intelligence",
    icon: "search",
    inputs: 1,
    outputs: 1,
    color: "#10b981",
    configFields: [
      {
        name: "source",
        label: "Intel Source",
        type: "select",
        required: true,
        options: [
          { value: "internal", label: "Internal Database" },
          { value: "virustotal", label: "VirusTotal" },
          { value: "mandiant", label: "Mandiant" },
          { value: "crowdstrike", label: "CrowdStrike" },
        ],
      },
      {
        name: "dataType",
        label: "Data Type",
        type: "select",
        required: true,
        options: [
          { value: "ip", label: "IP Address" },
          { value: "domain", label: "Domain" },
          { value: "hash", label: "File Hash" },
          { value: "url", label: "URL" },
        ],
      },
    ],
  },
  {
    type: "malwareAnalysis",
    category: "analysis",
    label: "Malware Analysis",
    description: "Analyzes files for malicious content",
    icon: "bug",
    inputs: 1,
    outputs: 1,
    color: "#10b981",
    configFields: [
      {
        name: "sandbox",
        label: "Sandbox Environment",
        type: "select",
        required: true,
        options: [
          { value: "internal", label: "Internal Sandbox" },
          { value: "cuckoo", label: "Cuckoo Sandbox" },
          { value: "fireeye", label: "FireEye" },
        ],
      },
      {
        name: "timeout",
        label: "Analysis Timeout (seconds)",
        type: "number",
        defaultValue: 300,
      },
    ],
  },

  // Actions
  {
    type: "blockIP",
    category: "actions",
    label: "Block IP",
    description: "Blocks an IP address on the firewall",
    icon: "shield",
    inputs: 1,
    outputs: 1,
    color: "#ef4444",
    configFields: [
      {
        name: "firewallType",
        label: "Firewall Type",
        type: "select",
        required: true,
        options: [
          { value: "cisco", label: "Cisco ASA" },
          { value: "paloalto", label: "Palo Alto" },
          { value: "checkpoint", label: "Check Point" },
          { value: "fortinet", label: "Fortinet" },
        ],
      },
      {
        name: "duration",
        label: "Block Duration (hours)",
        type: "number",
        defaultValue: 24,
      },
    ],
  },
  {
    type: "quarantineHost",
    category: "actions",
    label: "Quarantine Host",
    description: "Isolates a host from the network",
    icon: "laptop",
    inputs: 1,
    outputs: 1,
    color: "#ef4444",
    configFields: [
      {
        name: "endpoint",
        label: "Endpoint Solution",
        type: "select",
        required: true,
        options: [
          { value: "crowdstrike", label: "CrowdStrike" },
          { value: "sentinelone", label: "SentinelOne" },
          { value: "carbonblack", label: "Carbon Black" },
          { value: "microsoft", label: "Microsoft Defender" },
        ],
      },
    ],
  },

  // Logic
  {
    type: "condition",
    category: "logic",
    label: "Condition",
    description: "Routes workflow based on conditions",
    icon: "git-branch",
    inputs: 1,
    outputs: 2,
    color: "#f59e0b",
    configFields: [
      {
        name: "condition",
        label: "Condition",
        type: "code",
        required: true,
        placeholder: "data.risk_score > 80",
      },
    ],
  },
  {
    type: "switch",
    category: "logic",
    label: "Switch",
    description: "Routes workflow based on a value",
    icon: "switch-camera",
    inputs: 1,
    outputs: 3,
    color: "#f59e0b",
    configFields: [
      {
        name: "field",
        label: "Field to Evaluate",
        type: "text",
        required: true,
        placeholder: "data.alert_type",
      },
      {
        name: "cases",
        label: "Cases (comma separated)",
        type: "text",
        required: true,
        placeholder: "phishing,malware,data_leak",
      },
    ],
  },

  // Notification
  {
    type: "email",
    category: "notification",
    label: "Send Email",
    description: "Sends an email notification",
    icon: "mail",
    inputs: 1,
    outputs: 1,
    color: "#8b5cf6",
    configFields: [
      {
        name: "to",
        label: "To",
        type: "text",
        required: true,
        placeholder: "soc@example.mil",
      },
      {
        name: "subject",
        label: "Subject",
        type: "text",
        required: true,
        placeholder: "Security Alert: {{data.alert_type}}",
      },
      {
        name: "body",
        label: "Body",
        type: "textarea",
        required: true,
        placeholder: "Alert details:\n{{data.details}}",
      },
    ],
  },
  {
    type: "ticket",
    category: "notification",
    label: "Create Ticket",
    description: "Creates a ticket in the ticketing system",
    icon: "ticket",
    inputs: 1,
    outputs: 1,
    color: "#8b5cf6",
    configFields: [
      {
        name: "system",
        label: "Ticketing System",
        type: "select",
        required: true,
        options: [
          { value: "jira", label: "Jira" },
          { value: "servicenow", label: "ServiceNow" },
          { value: "remedy", label: "BMC Remedy" },
        ],
      },
      {
        name: "title",
        label: "Title",
        type: "text",
        required: true,
        placeholder: "Security Incident: {{data.alert_type}}",
      },
      {
        name: "priority",
        label: "Priority",
        type: "select",
        required: true,
        options: [
          { value: "low", label: "Low" },
          { value: "medium", label: "Medium" },
          { value: "high", label: "High" },
          { value: "critical", label: "Critical" },
        ],
      },
    ],
  },

  // DOD Specific
  {
    type: "crossDomainTransfer",
    category: "dod",
    label: "Cross-Domain Transfer",
    description: "Securely transfers data across classification boundaries",
    icon: "filter",
    inputs: 1,
    outputs: 1,
    color: "#0f766e",
    configFields: [
      {
        name: "sourceClassification",
        label: "Source Classification",
        type: "select",
        required: true,
        options: CLASSIFICATION_LEVELS.map((level) => ({ value: level.id, label: level.label })),
      },
      {
        name: "targetClassification",
        label: "Target Classification",
        type: "select",
        required: true,
        options: CLASSIFICATION_LEVELS.map((level) => ({ value: level.id, label: level.label })),
      },
      {
        name: "guardType",
        label: "Guard Type",
        type: "select",
        required: true,
        options: [
          { value: "owl", label: "Data Diode (OWL)" },
          { value: "guard", label: "Content Filter Guard" },
          { value: "manual", label: "Manual Review" },
        ],
      },
    ],
  },
  {
    type: "classificationCheck",
    category: "dod",
    label: "Classification Check",
    description: "Validates data classification",
    icon: "shield-alert",
    inputs: 1,
    outputs: 1,
    color: "#0f766e",
    configFields: [
      {
        name: "requiredClassification",
        label: "Required Classification",
        type: "select",
        required: true,
        options: CLASSIFICATION_LEVELS.map((level) => ({ value: level.id, label: level.label })),
      },
      {
        name: "action",
        label: "If Mismatch",
        type: "select",
        required: true,
        options: [
          { value: "block", label: "Block Processing" },
          { value: "escalate", label: "Escalate Classification" },
          { value: "log", label: "Log Warning Only" },
        ],
      },
    ],
  },
]

export function getNodeTypeInfo(type: string): NodeTypeInfo | undefined {
  return NODE_TYPES.find((nodeType) => nodeType.type === type)
}

export const NODE_CATEGORIES = [
  { id: "triggers", label: "Triggers", color: "#3b82f6" },
  { id: "analysis", label: "Analysis", color: "#10b981" },
  { id: "actions", label: "Actions", color: "#ef4444" },
  { id: "logic", label: "Logic", color: "#f59e0b" },
  { id: "notification", label: "Notification", color: "#8b5cf6" },
  { id: "dod", label: "DOD Specific", color: "#0f766e" },
]
