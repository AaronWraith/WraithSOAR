"use client"

import { create } from "zustand"
import { nanoid } from "nanoid"
import { getNodeTypeInfo } from "./node-types"
import type { ClassificationLevel } from "./classification"

// Define simplified types without reactflow dependencies
interface NodePosition {
  x: number
  y: number
}

interface NodeData {
  type: string
  label: string
  icon: string
  color: string
  inputs: number
  outputs: number
  config: Record<string, any>
}

interface Node {
  id: string
  type: string
  position: NodePosition
  data: NodeData
}

interface Edge {
  id: string
  source: string
  target: string
  sourceHandle?: string
  targetHandle?: string
}

interface Connection {
  source?: string
  target?: string
  sourceHandle?: string
  targetHandle?: string
}

export interface WorkflowState {
  nodes: Node[]
  edges: Edge[]
  classification: ClassificationLevel
  name: string
  description: string
  selectedNodeId: string | null
  isDragging: boolean

  // Actions
  setNodes: (nodes: Node[]) => void
  setEdges: (edges: Edge[]) => void
  addNode: (type: string, position: NodePosition) => void
  updateNodeData: (nodeId: string, data: any) => void
  removeNode: (nodeId: string) => void
  onNodesChange: (changes: any) => void
  onEdgesChange: (changes: any) => void
  onConnect: (connection: Connection) => void
  setClassification: (classification: ClassificationLevel) => void
  setName: (name: string) => void
  setDescription: (description: string) => void
  setSelectedNodeId: (nodeId: string | null) => void
  setIsDragging: (isDragging: boolean) => void
  clearWorkflow: () => void
  loadWorkflow: (workflow: any) => void
}

export const useWorkflowStore = create<WorkflowState>((set, get) => ({
  nodes: [],
  edges: [],
  classification: "unclassified",
  name: "New Workflow",
  description: "Workflow description",
  selectedNodeId: null,
  isDragging: false,

  setNodes: (nodes) => set({ nodes }),
  setEdges: (edges) => set({ edges }),

  addNode: (type, position) => {
    const nodeTypeInfo = getNodeTypeInfo(type)
    if (!nodeTypeInfo) return

    const newNode: Node = {
      id: nanoid(),
      type: "customNode",
      position,
      data: {
        type,
        label: nodeTypeInfo.label,
        icon: nodeTypeInfo.icon,
        color: nodeTypeInfo.color,
        inputs: nodeTypeInfo.inputs,
        outputs: nodeTypeInfo.outputs,
        config: {},
      },
    }

    set((state) => ({
      nodes: [...state.nodes, newNode],
      selectedNodeId: newNode.id,
    }))
  },

  updateNodeData: (nodeId, data) => {
    set((state) => ({
      nodes: state.nodes.map((node) => {
        if (node.id === nodeId) {
          return {
            ...node,
            data: {
              ...node.data,
              ...data,
            },
          }
        }
        return node
      }),
    }))
  },

  removeNode: (nodeId) => {
    set((state) => ({
      nodes: state.nodes.filter((node) => node.id !== nodeId),
      edges: state.edges.filter((edge) => edge.source !== nodeId && edge.target !== nodeId),
      selectedNodeId: state.selectedNodeId === nodeId ? null : state.selectedNodeId,
    }))
  },

  onNodesChange: (changes) => {
    set((state) => {
      const { nodes } = state
      // Apply changes to nodes (this would typically use a library like immer)
      // For simplicity, we'll just handle deletion here
      const updatedNodes = [...nodes]

      changes.forEach((change: any) => {
        if (change.type === "remove") {
          const index = updatedNodes.findIndex((node) => node.id === change.id)
          if (index !== -1) {
            updatedNodes.splice(index, 1)
          }
        }
      })

      return { nodes: updatedNodes }
    })
  },

  onEdgesChange: (changes) => {
    set((state) => {
      const { edges } = state
      // Apply changes to edges (this would typically use a library like immer)
      // For simplicity, we'll just handle deletion here
      const updatedEdges = [...edges]

      changes.forEach((change: any) => {
        if (change.type === "remove") {
          const index = updatedEdges.findIndex((edge) => edge.id === change.id)
          if (index !== -1) {
            updatedEdges.splice(index, 1)
          }
        }
      })

      return { edges: updatedEdges }
    })
  },

  onConnect: (connection) => {
    if (!connection.source || !connection.target) return

    const newEdge = {
      id: nanoid(),
      source: connection.source,
      target: connection.target,
      sourceHandle: connection.sourceHandle,
      targetHandle: connection.targetHandle,
    }

    set((state) => ({
      edges: [...state.edges, newEdge],
    }))
  },

  setClassification: (classification) => set({ classification }),
  setName: (name) => set({ name }),
  setDescription: (description) => set({ description }),
  setSelectedNodeId: (nodeId) => set({ selectedNodeId: nodeId }),
  setIsDragging: (isDragging) => set({ isDragging }),

  clearWorkflow: () =>
    set({
      nodes: [],
      edges: [],
      name: "New Workflow",
      description: "Workflow description",
      selectedNodeId: null,
    }),

  loadWorkflow: (workflow) =>
    set({
      nodes: workflow.nodes || [],
      edges: workflow.edges || [],
      name: workflow.name || "Imported Workflow",
      description: workflow.description || "Imported workflow description",
      classification: workflow.classification || "unclassified",
    }),
}))
