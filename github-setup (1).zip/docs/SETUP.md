# Setting Up the WRAITH SOAR Repository

This guide will walk you through setting up the WRAITH SOAR repository for development.

## Prerequisites

Before you begin, ensure you have the following installed:

- Node.js 18.x or higher
- npm 9.x or higher
- Git

## Clone the Repository

\`\`\`bash
git clone https://github.com/your-organization/wraith-soar.git
cd wraith-soar
\`\`\`

## Install Dependencies

\`\`\`bash
npm install
\`\`\`

This will install all dependencies for the monorepo and its packages.

## Development Workflow

### Running the Marketing Site

\`\`\`bash
npm run dev:marketing
\`\`\`

This will start the development server for the marketing site at http://localhost:3000.

### Running the Demo

\`\`\`bash
npm run dev:demo
\`\`\`

This will start the development server for the demo at http://localhost:3001.

### Building All Packages

\`\`\`bash
npm run build
\`\`\`

This will build all packages in the monorepo.

## Project Structure

The project is organized as a monorepo with the following packages:

- `packages/marketing`: The public marketing website
- `packages/ui`: Shared UI components
- `packages/demo`: Interactive demo components
- `packages/types`: TypeScript type definitions

## Security Considerations

When contributing to this repository, please keep the following security considerations in mind:

1. **Do not commit sensitive information**:
   - API keys
   - Credentials
   - Private keys
   - Sensitive configuration

2. **Do not include actual implementation details** of security-critical components:
   - Authentication mechanisms
   - Encryption algorithms
   - Security verification code

3. **Follow the security boundaries** defined in the README:
   - Keep platform code separate
   - Do not include actual platform implementation
   - Only include public interfaces and demo components

## Deployment

The marketing site and demo can be deployed to Vercel or any other hosting provider that supports Next.js applications.

### Deploying to Vercel

1. Create a new project in Vercel
2. Connect it to your GitHub repository
3. Set the root directory to `packages/marketing` or `packages/demo`
4. Deploy

## Troubleshooting

If you encounter any issues during setup or development, please check the following:

1. Ensure you have the correct Node.js version installed
2. Make sure all dependencies are installed correctly
3. Check for any error messages in the console

If you still have issues, please open an issue on GitHub.
