"use client"

import { useState, useEffect } from "react"
import { useWorkflowStore } from "@/lib/workflow-store"
import { getNodeTypeInfo } from "@/lib/node-types"
import { X, Settings, Info } from "lucide-react"
import * as LucideIcons from "lucide-react"

export default function PropertiesPanel() {
  const { nodes, selectedNodeId, updateNodeData, setName, setDescription, name, description, setSelectedNodeId } =
    useWorkflowStore()
  const [localConfig, setLocalConfig] = useState<Record<string, any>>({})
  const [localName, setLocalName] = useState(name)
  const [localDescription, setLocalDescription] = useState(description)

  const selectedNode = nodes.find((node) => node.id === selectedNodeId)
  const nodeTypeInfo = selectedNode ? getNodeTypeInfo(selectedNode.data.type) : undefined

  useEffect(() => {
    if (selectedNode) {
      setLocalConfig(selectedNode.data.config || {})
    } else {
      setLocalConfig({})
    }
  }, [selectedNode])

  useEffect(() => {
    setLocalName(name)
  }, [name])

  useEffect(() => {
    setLocalDescription(description)
  }, [description])

  const handleConfigChange = (field: string, value: any) => {
    setLocalConfig((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  const handleSave = () => {
    if (selectedNode) {
      updateNodeData(selectedNode.id, { config: localConfig })
    }
  }

  const handleWorkflowNameSave = () => {
    setName(localName)
  }

  const handleWorkflowDescriptionSave = () => {
    setDescription(localDescription)
  }

  if (!selectedNode) {
    return (
      <div className="h-full flex flex-col border-l bg-background">
        <div className="p-3 border-b">
          <h3 className="font-semibold text-sm">Workflow Properties</h3>
        </div>
        <div className="p-4 space-y-4 overflow-y-auto">
          <div>
            <label className="block text-sm font-medium mb-1.5 text-foreground/80">Name</label>
            <div className="flex gap-2">
              <input
                type="text"
                value={localName}
                onChange={(e) => setLocalName(e.target.value)}
                className="flex-1 p-2 text-sm border rounded-md bg-background"
                placeholder="Enter workflow name"
              />
              <button
                onClick={handleWorkflowNameSave}
                className="px-2.5 py-1 bg-primary text-primary-foreground text-xs rounded-md hover:bg-primary/90 transition-colors"
              >
                Save
              </button>
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1.5 text-foreground/80">Description</label>
            <textarea
              value={localDescription}
              onChange={(e) => setLocalDescription(e.target.value)}
              className="w-full p-2 text-sm border rounded-md bg-background h-24 resize-none"
              placeholder="Enter workflow description"
            />
            <button
              onClick={handleWorkflowDescriptionSave}
              className="mt-2 px-2.5 py-1 bg-primary text-primary-foreground text-xs rounded-md hover:bg-primary/90 transition-colors"
            >
              Save
            </button>
          </div>

          <div className="mt-8 border-t pt-4">
            <div className="bg-blue-500/10 text-blue-500 rounded-md p-3">
              <div className="flex items-start gap-2">
                <Info className="w-4 h-4 mt-0.5" />
                <div className="text-xs leading-relaxed">
                  <p className="font-medium mb-1">Workflow Builder Tips</p>
                  <ul className="space-y-1 list-disc pl-4">
                    <li>Add nodes from the palette on the left</li>
                    <li>Click on a node to edit its properties</li>
                    <li>Configure node settings in this panel</li>
                    <li>Use the toolbar to save or run your workflow</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="h-full flex flex-col border-l bg-background">
      <div className="p-3 border-b flex justify-between items-center">
        <h3 className="font-semibold text-sm">Node Properties</h3>
        <button className="p-1 rounded-md hover:bg-muted transition-colors" onClick={() => setSelectedNodeId(null)}>
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="p-4 space-y-4 overflow-y-auto">
        <div className="flex items-center gap-3 pb-3 border-b">
          {nodeTypeInfo && (
            <div
              className="w-10 h-10 rounded-full flex items-center justify-center shadow-sm"
              style={{ backgroundColor: nodeTypeInfo.color }}
            >
              {nodeTypeInfo.icon &&
                (LucideIcons as any)[nodeTypeInfo.icon.charAt(0).toUpperCase() + nodeTypeInfo.icon.slice(1)]({
                  className: "w-5 h-5 text-white",
                })}
            </div>
          )}
          <div>
            <div className="font-medium">{nodeTypeInfo?.label}</div>
            <div className="text-xs text-muted-foreground">{nodeTypeInfo?.description}</div>
          </div>
        </div>

        <div className="pt-2">
          <h4 className="font-medium text-sm mb-3 flex items-center gap-1.5">
            <Settings className="w-4 h-4" />
            <span>Configuration</span>
          </h4>

          {nodeTypeInfo?.configFields.map((field) => (
            <div key={field.name} className="mb-4">
              <label className="block text-sm font-medium mb-1.5 text-foreground/80">{field.label}</label>

              {field.type === "text" && (
                <input
                  type="text"
                  value={localConfig[field.name] || ""}
                  onChange={(e) => handleConfigChange(field.name, e.target.value)}
                  placeholder={field.placeholder}
                  className="w-full p-2 text-sm border rounded-md bg-background"
                />
              )}

              {field.type === "select" && (
                <select
                  value={localConfig[field.name] || ""}
                  onChange={(e) => handleConfigChange(field.name, e.target.value)}
                  className="w-full p-2 text-sm border rounded-md bg-background"
                >
                  <option value="">Select...</option>
                  {field.options?.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              )}

              {field.type === "number" && (
                <input
                  type="number"
                  value={localConfig[field.name] || field.defaultValue || ""}
                  onChange={(e) => handleConfigChange(field.name, Number.parseInt(e.target.value))}
                  className="w-full p-2 text-sm border rounded-md bg-background"
                />
              )}

              {field.type === "boolean" && (
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id={`field-${field.name}`}
                    checked={localConfig[field.name] || false}
                    onChange={(e) => handleConfigChange(field.name, e.target.checked)}
                    className="rounded border-gray-300 mr-2"
                  />
                  <label htmlFor={`field-${field.name}`} className="text-sm">
                    Enabled
                  </label>
                </div>
              )}

              {field.type === "textarea" && (
                <textarea
                  value={localConfig[field.name] || ""}
                  onChange={(e) => handleConfigChange(field.name, e.target.value)}
                  placeholder={field.placeholder}
                  className="w-full p-2 text-sm border rounded-md bg-background h-24 resize-none"
                />
              )}

              {field.type === "code" && (
                <textarea
                  value={localConfig[field.name] || ""}
                  onChange={(e) => handleConfigChange(field.name, e.target.value)}
                  placeholder={field.placeholder}
                  className="w-full p-2 text-sm border rounded-md bg-background h-24 font-mono text-xs resize-none"
                />
              )}
            </div>
          ))}

          <button
            onClick={handleSave}
            className="px-4 py-2 bg-primary text-primary-foreground rounded-md mt-2 text-sm hover:bg-primary/90 transition-colors w-full"
          >
            Apply Changes
          </button>
        </div>
      </div>
    </div>
  )
}
