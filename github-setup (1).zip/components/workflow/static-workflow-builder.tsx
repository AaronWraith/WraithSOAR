"use client"

import { useState } from "react"
import { useWorkflowStore } from "@/lib/workflow-store"
import { Download, Upload, Save, Play, Trash2, Plus, ArrowRight, Settings } from "lucide-react"
import * as LucideIcons from "lucide-react"
import type { LucideIcon } from "lucide-react"
import { NODE_TYPES } from "@/lib/node-types"

export default function StaticWorkflowBuilder() {
  const { nodes, edges, clearWorkflow, name, addNode, removeNode, setSelectedNodeId, selectedNodeId } =
    useWorkflowStore()
  const [showMessage, setShowMessage] = useState(false)

  const handleSaveWorkflow = () => {
    setShowMessage(true)
    setTimeout(() => setShowMessage(false), 3000)
  }

  const handleRunWorkflow = () => {
    setShowMessage(true)
    setTimeout(() => setShowMessage(false), 3000)
  }

  const handleExportWorkflow = () => {
    setShowMessage(true)
    setTimeout(() => setShowMessage(false), 3000)
  }

  const handleImportWorkflow = () => {
    setShowMessage(true)
    setTimeout(() => setShowMessage(false), 3000)
  }

  const handleAddNode = () => {
    // Add a sample node at a random position
    const randomType = NODE_TYPES[Math.floor(Math.random() * NODE_TYPES.length)].type
    addNode(randomType, { x: Math.random() * 500, y: Math.random() * 300 })
  }

  // Get connected nodes for a given node
  const getConnectedNodes = (nodeId: string) => {
    return edges
      .filter((edge) => edge.source === nodeId)
      .map((edge) => nodes.find((node) => node.id === edge.target))
      .filter(Boolean)
  }

  return (
    <div className="h-full flex flex-col border rounded-md overflow-hidden bg-background">
      <div className="border-b p-3 flex justify-between items-center bg-muted/30">
        <div className="flex items-center">
          <h3 className="font-medium text-base">{name || "New Workflow"}</h3>
          {nodes.length > 0 && (
            <span className="ml-2 text-xs bg-muted px-2 py-0.5 rounded-full">
              {nodes.length} node{nodes.length !== 1 ? "s" : ""}
            </span>
          )}
        </div>
        <div className="flex gap-1.5">
          <button
            onClick={handleSaveWorkflow}
            className="p-1.5 bg-background border rounded-md hover:bg-muted transition-colors"
            title="Save Workflow"
          >
            <Save className="w-4 h-4" />
          </button>
          <button
            onClick={handleRunWorkflow}
            className="p-1.5 bg-primary text-primary-foreground rounded-md hover:bg-primary/90 transition-colors"
            title="Run Workflow"
          >
            <Play className="w-4 h-4" />
          </button>
          <button
            onClick={handleExportWorkflow}
            className="p-1.5 bg-background border rounded-md hover:bg-muted transition-colors"
            title="Export Workflow"
          >
            <Download className="w-4 h-4" />
          </button>
          <button
            onClick={handleImportWorkflow}
            className="p-1.5 bg-background border rounded-md hover:bg-muted transition-colors"
            title="Import Workflow"
          >
            <Upload className="w-4 h-4" />
          </button>
          <button
            onClick={clearWorkflow}
            className="p-1.5 bg-destructive text-destructive-foreground rounded-md hover:bg-destructive/90 transition-colors"
            title="Clear Workflow"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="flex-1 p-6 relative bg-muted/10 overflow-auto">
        {nodes.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center border-2 border-dashed border-muted rounded-md p-8">
            <div className="text-center max-w-md">
              <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-primary">
                <Settings className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-medium mb-3">Start Building Your Workflow</h3>
              <p className="text-muted-foreground mb-6 text-sm leading-relaxed">
                Create powerful security automation workflows by adding nodes from the palette on the left. This is a
                simplified preview of the workflow builder.
              </p>
              <button
                onClick={handleAddNode}
                className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90 transition-colors mx-auto"
              >
                <Plus className="w-4 h-4" />
                <span>Add Sample Node</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="relative min-h-[600px]">
            {/* Render nodes */}
            {nodes.map((node) => {
              const IconComponent =
                (LucideIcons as Record<string, LucideIcon>)[
                  node.data.icon.charAt(0).toUpperCase() + node.data.icon.slice(1)
                ] || LucideIcons.HelpCircle

              // Get connected nodes
              const connectedNodes = getConnectedNodes(node.id)

              return (
                <div key={node.id}>
                  {/* Render connection lines */}
                  {connectedNodes.map((targetNode) => (
                    <div
                      key={`${node.id}-${targetNode?.id}`}
                      className="absolute border-t-2 border-muted-foreground/40"
                      style={{
                        top: `${node.position.y + 40}px`,
                        left: `${node.position.x + 180}px`,
                        width: `${(targetNode?.position.x || 0) - node.position.x - 180}px`,
                        transform: "translateY(-50%)",
                      }}
                    >
                      <ArrowRight
                        className="absolute right-0 top-0 transform -translate-y-1/2"
                        size={16}
                        color="var(--muted-foreground)"
                      />
                    </div>
                  ))}

                  {/* Render node */}
                  <div
                    className={`absolute border rounded-md shadow-sm bg-card w-48 transition-all ${
                      selectedNodeId === node.id ? "ring-2 ring-primary" : ""
                    }`}
                    style={{
                      transform: `translate(${node.position.x}px, ${node.position.y}px)`,
                    }}
                    onClick={() => setSelectedNodeId(node.id)}
                  >
                    <div
                      className="flex items-center justify-between p-3 border-b rounded-t-md"
                      style={{ backgroundColor: node.data.color + "20" }}
                    >
                      <div className="flex items-center">
                        <div
                          className="w-8 h-8 rounded-full flex items-center justify-center mr-2 shadow-sm"
                          style={{ backgroundColor: node.data.color }}
                        >
                          <IconComponent className="w-4 h-4 text-white" />
                        </div>
                        <div className="text-sm font-medium truncate">{node.data.label}</div>
                      </div>
                      <button
                        onClick={(e) => {
                          e.stopPropagation()
                          removeNode(node.id)
                        }}
                        className="text-muted-foreground hover:text-foreground transition-colors p-1 rounded-full hover:bg-muted"
                        title="Remove node"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>

                    <div className="p-3 text-xs text-muted-foreground">
                      {Object.entries(node.data.config || {}).length > 0 ? (
                        <ul className="space-y-1.5">
                          {Object.entries(node.data.config || {}).map(([key, value]) => (
                            <li key={key} className="truncate">
                              <span className="font-medium text-foreground/80">{key}:</span>{" "}
                              <span className="text-foreground/60">{String(value)}</span>
                            </li>
                          ))}
                        </ul>
                      ) : (
                        <p className="text-center py-1 text-muted-foreground/80">Configure this node in the panel →</p>
                      )}
                    </div>

                    {/* Connection points */}
                    <div className="absolute top-1/2 right-0 w-3 h-3 bg-primary rounded-full transform translate-x-1/2 -translate-y-1/2 border-2 border-background"></div>
                    {node.data.inputs > 0 && (
                      <div className="absolute top-1/2 left-0 w-3 h-3 bg-primary rounded-full transform -translate-x-1/2 -translate-y-1/2 border-2 border-background"></div>
                    )}
                  </div>
                </div>
              )
            })}
          </div>
        )}

        <div className="absolute bottom-4 right-4 bg-background border rounded-md shadow-md p-3 max-w-xs">
          <div className="flex items-start gap-2">
            <div className="bg-blue-500/10 text-blue-500 p-1 rounded">
              <Settings className="w-4 h-4" />
            </div>
            <p className="text-xs leading-relaxed">
              This is a simplified preview of the workflow builder. The full version uses ReactFlow for interactive
              drag-and-drop functionality.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
