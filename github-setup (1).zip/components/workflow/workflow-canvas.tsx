"use client"

import StaticWorkflowBuilder from "./static-workflow-builder"

export default function WorkflowCanvas() {
  return <StaticWorkflowBuilder />
}
