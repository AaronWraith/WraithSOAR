"use client"

import { memo, useEffect, useState } from "react"
import dynamic from "next/dynamic"

// Dynamically import ReactFlow components
const getBezierPath = dynamic(() => import("reactflow").then((mod) => mod.getBezierPath), { ssr: false })

interface EdgeProps {
  id: string
  sourceX: number
  sourceY: number
  targetX: number
  targetY: number
  sourcePosition: string
  targetPosition: string
  style?: Record<string, any>
  markerEnd?: string
}

const CustomEdge = memo(
  ({ id, sourceX, sourceY, targetX, targetY, sourcePosition, targetPosition, style = {}, markerEnd }: EdgeProps) => {
    const [isClient, setIsClient] = useState(false)
    const [edgePath, setEdgePath] = useState("")

    useEffect(() => {
      setIsClient(true)

      // Simple bezier curve calculation for SSR
      const controlX = (sourceX + targetX) / 2
      const path = `M${sourceX},${sourceY} C${controlX},${sourceY} ${controlX},${targetY} ${targetX},${targetY}`
      setEdgePath(path)
    }, [sourceX, sourceY, targetX, targetY])

    // If we're on the client and getBezierPath is available, use it
    useEffect(() => {
      if (isClient && getBezierPath) {
        import("reactflow").then((mod) => {
          const [path] = mod.getBezierPath({
            sourceX,
            sourceY,
            sourcePosition: sourcePosition as any,
            targetX,
            targetY,
            targetPosition: targetPosition as any,
          })
          setEdgePath(path)
        })
      }
    }, [isClient, sourceX, sourceY, targetX, targetY, sourcePosition, targetPosition])

    return (
      <path
        id={id}
        style={style}
        className="react-flow__edge-path stroke-muted-foreground"
        d={edgePath}
        markerEnd={markerEnd}
      />
    )
  },
)

CustomEdge.displayName = "CustomEdge"

export default CustomEdge
