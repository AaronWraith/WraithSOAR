"use client"

import { useState } from "react"
import { useWorkflowStore } from "@/lib/workflow-store"
import { Download, Upload, Save, Play, Trash2, Plus } from "lucide-react"
import * as LucideIcons from "lucide-react"
import type { LucideIcon } from "lucide-react"

export default function FallbackCanvas() {
  const { nodes, clearWorkflow, name } = useWorkflowStore()
  const [showMessage, setShowMessage] = useState(false)

  const handleSaveWorkflow = () => {
    setShowMessage(true)
    setTimeout(() => setShowMessage(false), 3000)
  }

  const handleRunWorkflow = () => {
    setShowMessage(true)
    setTimeout(() => setShowMessage(false), 3000)
  }

  const handleExportWorkflow = () => {
    setShowMessage(true)
    setTimeout(() => setShowMessage(false), 3000)
  }

  const handleImportWorkflow = () => {
    setShowMessage(true)
    setTimeout(() => setShowMessage(false), 3000)
  }

  return (
    <div className="h-full flex flex-col">
      <div className="border-b p-4 flex justify-between items-center">
        <h3 className="font-medium">{name || "New Workflow"}</h3>
        <div className="flex gap-2">
          <button
            onClick={handleSaveWorkflow}
            className="p-2 bg-background border rounded-md hover:bg-muted"
            title="Save Workflow"
          >
            <Save className="w-4 h-4" />
          </button>
          <button
            onClick={handleRunWorkflow}
            className="p-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90"
            title="Run Workflow"
          >
            <Play className="w-4 h-4" />
          </button>
          <button
            onClick={handleExportWorkflow}
            className="p-2 bg-background border rounded-md hover:bg-muted"
            title="Export Workflow"
          >
            <Download className="w-4 h-4" />
          </button>
          <button
            onClick={handleImportWorkflow}
            className="p-2 bg-background border rounded-md hover:bg-muted"
            title="Import Workflow"
          >
            <Upload className="w-4 h-4" />
          </button>
          <button
            onClick={clearWorkflow}
            className="p-2 bg-destructive text-destructive-foreground rounded-md hover:bg-destructive/90"
            title="Clear Workflow"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="flex-1 p-4 relative">
        {nodes.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center border-2 border-dashed border-muted rounded-md p-6">
            <div className="text-center">
              <h3 className="text-lg font-medium mb-2">Start Building Your Workflow</h3>
              <p className="text-muted-foreground mb-4">
                Drag nodes from the palette on the left to create your workflow
              </p>
              <button className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-md">
                <Plus className="w-4 h-4" />
                <span>Add First Node</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {nodes.map((node) => {
              const IconComponent =
                (LucideIcons as Record<string, LucideIcon>)[
                  node.data.icon.charAt(0).toUpperCase() + node.data.icon.slice(1)
                ] || LucideIcons.HelpCircle

              return (
                <div
                  key={node.id}
                  className="border rounded-md shadow-sm bg-card"
                  style={{ transform: `translate(${node.position.x % 300}px, ${node.position.y % 200}px)` }}
                >
                  <div
                    className="flex items-center p-3 border-b rounded-t-md"
                    style={{ backgroundColor: node.data.color + "20" }}
                  >
                    <div
                      className="w-8 h-8 rounded-full flex items-center justify-center mr-2"
                      style={{ backgroundColor: node.data.color }}
                    >
                      <IconComponent className="w-4 h-4 text-white" />
                    </div>
                    <div className="text-sm font-medium truncate">{node.data.label}</div>
                  </div>

                  <div className="p-3 text-xs text-muted-foreground">
                    {Object.entries(node.data.config || {}).length > 0 ? (
                      <ul className="space-y-1">
                        {Object.entries(node.data.config || {}).map(([key, value]) => (
                          <li key={key} className="truncate">
                            <span className="font-medium">{key}:</span> {String(value)}
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <p>Configure this node in the panel</p>
                    )}
                  </div>
                </div>
              )
            })}
          </div>
        )}

        {showMessage && (
          <div className="absolute bottom-4 right-4 bg-background border rounded-md shadow-md p-3 animate-in fade-in slide-in-from-bottom-4">
            <p className="text-sm">
              Interactive workflow builder is not available in preview mode. Please try the full version.
            </p>
          </div>
        )}
      </div>
    </div>
  )
}
