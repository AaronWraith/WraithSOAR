"use client"
import { useState } from "react"
import { useWorkflowStore } from "@/lib/workflow-store"
import { NODE_CATEGORIES, NODE_TYPES } from "@/lib/node-types"
import * as LucideIcons from "lucide-react"
import type { LucideIcon } from "lucide-react"
import { Search } from "lucide-react"

export default function NodePalette() {
  const [selectedCategory, setSelectedCategory] = useState("triggers")
  const [searchQuery, setSearchQuery] = useState("")
  const addNode = useWorkflowStore((state) => state.addNode)

  const handleNodeClick = (nodeType: string) => {
    // Add node at a random position in the visible area
    const x = 100 + Math.random() * 300
    const y = 100 + Math.random() * 200
    addNode(nodeType, { x, y })
  }

  // Filter nodes by category and search query
  const filteredNodes = NODE_TYPES.filter(
    (node) =>
      node.category === selectedCategory &&
      (searchQuery === "" ||
        node.label.toLowerCase().includes(searchQuery.toLowerCase()) ||
        node.description.toLowerCase().includes(searchQuery.toLowerCase())),
  )

  return (
    <div className="h-full flex flex-col border-r bg-background">
      <div className="p-3 border-b">
        <h3 className="font-semibold text-sm">Node Palette</h3>
      </div>

      <div className="px-3 py-2 border-b">
        <div className="relative">
          <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
          <input
            type="text"
            placeholder="Search nodes..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-8 pr-3 py-1.5 text-sm border rounded-md bg-background"
          />
        </div>
      </div>

      <div className="flex overflow-x-auto border-b p-1.5 bg-muted/20">
        {NODE_CATEGORIES.map((category) => (
          <button
            key={category.id}
            className={`px-2.5 py-1 text-xs font-medium rounded-md whitespace-nowrap mr-1 transition-colors ${
              selectedCategory === category.id ? "bg-primary text-primary-foreground" : "bg-background hover:bg-muted"
            }`}
            onClick={() => setSelectedCategory(category.id)}
          >
            {category.label}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto p-3">
        {filteredNodes.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground text-sm">No nodes match your search</div>
        ) : (
          <div className="grid grid-cols-1 gap-2">
            {filteredNodes.map((node) => {
              const IconComponent =
                (LucideIcons as Record<string, LucideIcon>)[node.icon.charAt(0).toUpperCase() + node.icon.slice(1)] ||
                LucideIcons.HelpCircle

              return (
                <div
                  key={node.type}
                  className="border rounded-md p-2.5 bg-card cursor-pointer hover:border-primary hover:bg-muted/20 transition-colors"
                  onClick={() => handleNodeClick(node.type)}
                >
                  <div className="flex items-center">
                    <div
                      className="w-8 h-8 rounded-full flex items-center justify-center mr-2.5 shadow-sm"
                      style={{ backgroundColor: node.color }}
                    >
                      <IconComponent className="w-4 h-4 text-white" />
                    </div>
                    <div>
                      <div className="text-sm font-medium">{node.label}</div>
                      <div className="text-xs text-muted-foreground truncate max-w-[150px]">{node.description}</div>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}
