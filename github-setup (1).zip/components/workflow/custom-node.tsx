"use client"

import { memo, useEffect, useState } from "react"
import { useWorkflowStore } from "@/lib/workflow-store"
import dynamic from "next/dynamic"

// Dynamically import ReactFlow components
const Handle = dynamic(() => import("reactflow").then((mod) => mod.Handle), { ssr: false })

const Position = {
  Left: "left",
  Right: "right",
  Top: "top",
  Bottom: "bottom",
}

// Import all Lucide icons
import * as LucideIcons from "lucide-react"
import type { LucideIcon } from "lucide-react"

interface CustomNodeData {
  type: string
  label: string
  icon: string
  color: string
  inputs: number
  outputs: number
  config: Record<string, any>
}

interface NodeProps {
  id: string
  data: CustomNodeData
  selected: boolean
}

const CustomNode = memo(({ id, data, selected }: NodeProps) => {
  const setSelectedNodeId = useWorkflowStore((state) => state.setSelectedNodeId)
  const [isClient, setIsClient] = useState(false)

  useEffect(() => {
    setIsClient(true)
  }, [])

  // Dynamically get the icon from Lucide
  const IconComponent =
    (LucideIcons as Record<string, LucideIcon>)[data.icon.charAt(0).toUpperCase() + data.icon.slice(1)] ||
    LucideIcons.HelpCircle

  if (!isClient) {
    return (
      <div
        className={`relative rounded-md border shadow-sm bg-card w-48 transition-all ${
          selected ? "ring-2 ring-primary" : ""
        }`}
      >
        <div className="flex items-center p-3 border-b rounded-t-md" style={{ backgroundColor: data.color + "20" }}>
          <div
            className="w-8 h-8 rounded-full flex items-center justify-center mr-2"
            style={{ backgroundColor: data.color }}
          >
            <IconComponent className="w-4 h-4 text-white" />
          </div>
          <div className="text-sm font-medium truncate">{data.label}</div>
        </div>
        <div className="p-3 text-xs text-muted-foreground">
          <p>Loading node...</p>
        </div>
      </div>
    )
  }

  // Generate input handles
  const inputHandles = Array.from({ length: data.inputs }).map((_, index) => (
    <Handle
      key={`input-${index}`}
      type="target"
      position={Position.Left as any}
      id={`input-${index}`}
      className="w-3 h-3 bg-gray-700 dark:bg-gray-300"
      style={{ top: `${((index + 1) * 100) / (data.inputs + 1)}%` }}
    />
  ))

  // Generate output handles
  const outputHandles = Array.from({ length: data.outputs }).map((_, index) => (
    <Handle
      key={`output-${index}`}
      type="source"
      position={Position.Right as any}
      id={`output-${index}`}
      className="w-3 h-3 bg-gray-700 dark:bg-gray-300"
      style={{ top: `${((index + 1) * 100) / (data.outputs + 1)}%` }}
    />
  ))

  return (
    <div
      className={`relative rounded-md border shadow-sm bg-card w-48 transition-all ${
        selected ? "ring-2 ring-primary" : ""
      }`}
      onClick={() => setSelectedNodeId(id)}
    >
      <div className="flex items-center p-3 border-b rounded-t-md" style={{ backgroundColor: data.color + "20" }}>
        <div
          className="w-8 h-8 rounded-full flex items-center justify-center mr-2"
          style={{ backgroundColor: data.color }}
        >
          <IconComponent className="w-4 h-4 text-white" />
        </div>
        <div className="text-sm font-medium truncate">{data.label}</div>
      </div>

      <div className="p-3 text-xs text-muted-foreground">
        {Object.entries(data.config).length > 0 ? (
          <ul className="space-y-1">
            {Object.entries(data.config).map(([key, value]) => (
              <li key={key} className="truncate">
                <span className="font-medium">{key}:</span> {String(value)}
              </li>
            ))}
          </ul>
        ) : (
          <p>Configure this node in the panel</p>
        )}
      </div>

      {inputHandles}
      {outputHandles}
    </div>
  )
})

CustomNode.displayName = "CustomNode"

export default CustomNode
