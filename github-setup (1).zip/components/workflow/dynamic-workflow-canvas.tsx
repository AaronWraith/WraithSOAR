"use client"

import type React from "react"
import { useCallback, useRef } from "react"
import { useWorkflowStore } from "@/lib/workflow-store"
import { Download, Upload, Save, Play, Trash2 } from "lucide-react"
import ReactFlow, { Background, Controls, ReactFlowProvider, Panel, useReactFlow } from "reactflow"
import "reactflow/dist/style.css"
import CustomNode from "./custom-node"
import CustomEdge from "./custom-edge"

const nodeTypes = {
  customNode: CustomNode,
}

const edgeTypes = {
  customEdge: CustomEdge,
}

function WorkflowCanvasInner() {
  const { nodes, edges, onNodesChange, onEdgesChange, onConnect, addNode, clearWorkflow } = useWorkflowStore()
  const reactFlowInstance = useReactFlow()
  const reactFlowWrapper = useRef<HTMLDivElement>(null)

  const onDragOver = useCallback((event: React.DragEvent) => {
    event.preventDefault()
    event.dataTransfer.dropEffect = "move"
  }, [])

  const onDrop = useCallback(
    (event: React.DragEvent) => {
      event.preventDefault()

      if (!reactFlowWrapper.current || !reactFlowInstance) {
        return
      }

      const reactFlowBounds = reactFlowWrapper.current.getBoundingClientRect()
      const nodeType = event.dataTransfer.getData("application/reactflow")

      // Check if the dropped element is valid
      if (!nodeType) {
        return
      }

      const position = reactFlowInstance.project({
        x: event.clientX - reactFlowBounds.left,
        y: event.clientY - reactFlowBounds.top,
      })

      addNode(nodeType, position)
    },
    [reactFlowInstance, addNode],
  )

  const handleExportWorkflow = () => {
    const workflow = {
      nodes,
      edges,
      name: useWorkflowStore.getState().name,
      description: useWorkflowStore.getState().description,
      classification: useWorkflowStore.getState().classification,
    }

    const dataStr = JSON.stringify(workflow, null, 2)
    const dataUri = "data:application/json;charset=utf-8," + encodeURIComponent(dataStr)

    const exportFileDefaultName = `${workflow.name.replace(/\s+/g, "_")}.json`

    const linkElement = document.createElement("a")
    linkElement.setAttribute("href", dataUri)
    linkElement.setAttribute("download", exportFileDefaultName)
    linkElement.click()
  }

  const handleImportWorkflow = () => {
    const input = document.createElement("input")
    input.type = "file"
    input.accept = ".json"

    input.onchange = (e: any) => {
      const file = e.target.files[0]
      if (!file) return

      const reader = new FileReader()
      reader.onload = (event) => {
        try {
          const workflow = JSON.parse(event.target?.result as string)
          useWorkflowStore.getState().loadWorkflow(workflow)
        } catch (error) {
          console.error("Failed to parse workflow file:", error)
          alert("Invalid workflow file")
        }
      }
      reader.readAsText(file)
    }

    input.click()
  }

  const handleSaveWorkflow = () => {
    // In a real app, this would save to a backend
    alert("Workflow saved successfully!")
  }

  const handleRunWorkflow = () => {
    // In a real app, this would execute the workflow
    alert("Workflow execution started!")
  }

  return (
    <div className="h-full w-full" ref={reactFlowWrapper}>
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onConnect={onConnect}
        nodeTypes={nodeTypes}
        edgeTypes={edgeTypes}
        onDragOver={onDragOver}
        onDrop={onDrop}
        fitView
        deleteKeyCode="Delete"
      >
        <Background />
        <Controls />

        <Panel position="top-right" className="flex gap-2">
          <button
            onClick={handleSaveWorkflow}
            className="p-2 bg-background border rounded-md hover:bg-muted"
            title="Save Workflow"
          >
            <Save className="w-4 h-4" />
          </button>
          <button
            onClick={handleRunWorkflow}
            className="p-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90"
            title="Run Workflow"
          >
            <Play className="w-4 h-4" />
          </button>
          <button
            onClick={handleExportWorkflow}
            className="p-2 bg-background border rounded-md hover:bg-muted"
            title="Export Workflow"
          >
            <Download className="w-4 h-4" />
          </button>
          <button
            onClick={handleImportWorkflow}
            className="p-2 bg-background border rounded-md hover:bg-muted"
            title="Import Workflow"
          >
            <Upload className="w-4 h-4" />
          </button>
          <button
            onClick={clearWorkflow}
            className="p-2 bg-destructive text-destructive-foreground rounded-md hover:bg-destructive/90"
            title="Clear Workflow"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </Panel>
      </ReactFlow>
    </div>
  )
}

export default function DynamicWorkflowCanvas() {
  return (
    <ReactFlowProvider>
      <WorkflowCanvasInner />
    </ReactFlowProvider>
  )
}
