import type { ClassificationLevel } from "@/lib/classification"

interface ClassificationBannerProps {
  classification: ClassificationLevel
  showInfoIcon?: boolean
}

export function ClassificationBanner({ classification, showInfoIcon = false }: ClassificationBannerProps) {
  const getClassificationColor = (classification: string): string => {
    switch (classification) {
      case "cui":
        return "blue"
      case "confidential":
        return "purple"
      case "secret":
        return "red"
      case "topsecret":
        return "black"
      default:
        return "green"
    }
  }

  const getClassificationLabel = (classification: string): string => {
    switch (classification) {
      case "cui":
        return "CUI"
      case "confidential":
        return "CONFIDENTIAL"
      case "secret":
        return "SECRET"
      case "topsecret":
        return "TOP SECRET"
      default:
        return "UNCLASSIFIED"
    }
  }

  const getClassificationDescription = (classification: string): string => {
    switch (classification) {
      case "cui":
        return "Controlled Unclassified Information that requires safeguarding or dissemination controls"
      case "confidential":
        return "Information that could reasonably be expected to cause damage to national security"
      case "secret":
        return "Information that could reasonably be expected to cause serious damage to national security"
      case "topsecret":
        return "Information that could reasonably be expected to cause exceptionally grave damage to national security"
      default:
        return "Information that can be lawfully obtained by the general public"
    }
  }

  const color = getClassificationColor(classification)
  const label = getClassificationLabel(classification)
  const description = getClassificationDescription(classification)

  return (
    <div
      className="w-full py-1 text-center text-white font-bold text-sm flex items-center justify-center gap-2"
      style={{ backgroundColor: color }}
    >
      <span>{label} - WRAITH PLATFORM</span>
      {showInfoIcon && (
        <span className="cursor-help" title={description}>
          i
        </span>
      )}
    </div>
  )
}
