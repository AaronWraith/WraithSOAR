import { type ClassificationLevel, getClassificationInfo } from "@/lib/classification"

interface ClassificationBannerProps {
  classification: ClassificationLevel
  showInfoIcon?: boolean
}

export function ClassificationBanner({ classification, showInfoIcon = false }: ClassificationBannerProps) {
  const classInfo = getClassificationInfo(classification)

  return (
    <div
      className="w-full py-1 text-center text-white font-bold text-sm flex items-center justify-center gap-2"
      style={{ backgroundColor: classInfo.color }}
    >
      <span>{classInfo.label} - WRAITH PLATFORM</span>
      {showInfoIcon && (
        <span className="cursor-help" title={classInfo.description}>
          i
        </span>
      )}
    </div>
  )
}
