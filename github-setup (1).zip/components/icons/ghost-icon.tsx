export function GhostIcon({ className = "", size = 24 }) {
  return (
    <div className="relative neon-glow">
      {/* Glow effect */}
      <svg
        width={size}
        height={size}
        viewBox="0 0 24 24"
        fill="none"
        stroke="#39FF14"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className={`absolute blur-[2px] opacity-70 ${className}`}
        xmlns="http://www.w3.org/2000/svg"
      >
        <path d="M9 10h.01" />
        <path d="M15 10h.01" />
        <path d="M12 2a8 8 0 0 0-8 8v12l3-3 2.5 2.5L12 19l2.5 2.5L17 19l3 3V10a8 8 0 0 0-8-8z" />
      </svg>

      {/* Main icon */}
      <svg
        width={size}
        height={size}
        viewBox="0 0 24 24"
        fill="none"
        stroke="#39FF14"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className={`relative ${className}`}
        xmlns="http://www.w3.org/2000/svg"
      >
        <path d="M9 10h.01" />
        <path d="M15 10h.01" />
        <path d="M12 2a8 8 0 0 0-8 8v12l3-3 2.5 2.5L12 19l2.5 2.5L17 19l3 3V10a8 8 0 0 0-8-8z" />
      </svg>
    </div>
  )
}
