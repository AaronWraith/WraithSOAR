/**
 * This script prepares the codebase for sharing on GitHub by:
 * 1. Copying only the public components to a new directory
 * 2. Removing sensitive information
 * 3. Ensuring security boundaries are maintained
 *
 * Usage: node scripts/prepare-for-github.js
 */

const fs = require("fs")
const path = require("path")
const { execSync } = require("child_process")

// Configuration
const SOURCE_DIR = process.cwd()
const TARGET_DIR = path.join(process.cwd(), "github-ready")
const IGNORE_PATTERNS = [
  // Directories to ignore
  "node_modules",
  ".next",
  "dist",
  ".turbo",
  // Platform-specific directories
  "platform",
  "secure",
  "download-portal",
  "auth/implementation",
  // Sensitive files
  ".env",
  ".env.*",
  "secrets.ts",
  "secrets.js",
  // Private keys and certificates
  "*.pem",
  "*.key",
  "*.crt",
]

// Create target directory
console.log(`Creating target directory: ${TARGET_DIR}`)
if (fs.existsSync(TARGET_DIR)) {
  fs.rmSync(TARGET_DIR, { recursive: true, force: true })
}
fs.mkdirSync(TARGET_DIR, { recursive: true })

// Copy files
console.log("Copying files...")
function copyDir(src, dest) {
  // Create destination directory
  fs.mkdirSync(dest, { recursive: true })

  // Read source directory
  const entries = fs.readdirSync(src, { withFileTypes: true })

  for (const entry of entries) {
    const srcPath = path.join(src, entry.name)
    const destPath = path.join(dest, entry.name)

    // Skip ignored patterns
    if (
      IGNORE_PATTERNS.some((pattern) => {
        if (pattern.includes("*")) {
          const regex = new RegExp(pattern.replace("*", ".*"))
          return regex.test(entry.name)
        }
        return entry.name === pattern
      })
    ) {
      console.log(`Skipping: ${srcPath}`)
      continue
    }

    // Copy directories recursively
    if (entry.isDirectory()) {
      copyDir(srcPath, destPath)
    }
    // Copy files
    else {
      fs.copyFileSync(srcPath, destPath)
      console.log(`Copied: ${srcPath} -> ${destPath}`)
    }
  }
}

// Copy files from source to target
copyDir(SOURCE_DIR, TARGET_DIR)

// Remove .git directory from target
const gitDir = path.join(TARGET_DIR, ".git")
if (fs.existsSync(gitDir)) {
  fs.rmSync(gitDir, { recursive: true, force: true })
  console.log("Removed .git directory")
}

// Initialize new git repository in target
console.log("Initializing new git repository...")
execSync("git init", { cwd: TARGET_DIR })
execSync("git add .", { cwd: TARGET_DIR })
execSync('git commit -m "Initial commit"', { cwd: TARGET_DIR })

console.log(`
✅ Done! The GitHub-ready code is available at: ${TARGET_DIR}

Next steps:
1. Review the code to ensure no sensitive information is included
2. Create a new GitHub repository
3. Push the code to GitHub:
   cd ${TARGET_DIR}
   git remote add origin https://github.com/your-organization/wraith-soar.git
   git push -u origin main
`)
